import { config } from 'dotenv';
config();

import '@/ai/flows/agricultural-advice-chat-flow.ts';
import '@/ai/flows/crop-recommendation-flow.ts';