'use server';
/**
 * @fileOverview An AI chat assistant for farmers to get personalized advice in multiple languages.
 *
 * - agriculturalAdviceChat - A function that handles the AI chat assistant interaction.
 * - AgriculturalAdviceChatInput - The input type for the agriculturalAdviceChat function.
 * - AgriculturalAdviceChatOutput - The return type for the agriculturalAdviceChat function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AgriculturalAdviceChatInputSchema = z.object({
  message: z.string().describe('The current message from the farmer.'),
  language: z.string().default('English').describe('The preferred language for the response.'),
  chatHistory: z
    .array(
      z.object({
        role: z.enum(['user', 'model']).describe('The role of the sender.'),
        content: z.string().describe('The content of the message.'),
      })
    )
    .optional(),
  farmerProfile: z.any().optional().describe("The farmer's profile data for personalization."),
});
export type AgriculturalAdviceChatInput = z.infer<typeof AgriculturalAdviceChatInputSchema>;

const AgriculturalAdviceChatOutputSchema = z.object({
  response: z.string().describe("The AI assistant's response."),
});
export type AgriculturalAdviceChatOutput = z.infer<typeof AgriculturalAdviceChatOutputSchema>;

/**
 * System instruction for the AI advisor.
 */
const SYSTEM_INSTRUCTION = `You are AgriBot, an expert agricultural advisor. 
Your goal is to provide personalized, data-driven advice to farmers on crop selection, risk mitigation, and market opportunities.

Be helpful, empathetic, and professional. Use the context provided to give specific advice tailored to the farmer's region, land, and soil.
If no profile is provided, offer general best practices for sustainable farming.

Respond in the requested language.`;

const chatPrompt = ai.definePrompt({
  name: 'chatPrompt',
  input: { schema: AgriculturalAdviceChatInputSchema },
  output: { schema: z.string() },
  system: SYSTEM_INSTRUCTION,
  prompt: `
    Respond in the following language: {{{language}}}.
    
    FARMER PROFILE CONTEXT:
    {{#if farmerProfile}}
    {{{json farmerProfile}}}
    {{else}}
    No specific profile details available.
    {{/if}}

    USER MESSAGE:
    {{{message}}}
  `,
});

/**
 * Expert agricultural advice chat flow.
 * Uses Genkit 1.x history pattern for robust multi-turn conversation.
 */
export async function agriculturalAdviceChat(input: AgriculturalAdviceChatInput): Promise<AgriculturalAdviceChatOutput> {
  return agriculturalAdviceChatFlow(input);
}

const agriculturalAdviceChatFlow = ai.defineFlow(
  {
    name: 'agriculturalAdviceChatFlow',
    inputSchema: AgriculturalAdviceChatInputSchema,
    outputSchema: AgriculturalAdviceChatOutputSchema,
  },
  async (input) => {
    try {
      // Prepare the history for the generate call
      const history = (input.chatHistory || []).map((h) => ({
        role: h.role,
        content: [{ text: h.content }],
      }));

      const { text } = await chatPrompt(input, { history });

      if (!text) {
        throw new Error('Empty response from AI engine');
      }

      return {
        response: text,
      };
    } catch (error: any) {
      console.error('AgriBot Flow Error:', error);
      // Helpful fallback in case of API failure
      return {
        response:
          "I'm currently unable to access my specialized agricultural knowledge base. Please ensure your farm profile is complete and try again. For immediate sustainable advice: focus on soil aeration and localized irrigation monitoring.",
      };
    }
  }
);
