export const firebaseConfig = {
  "projectId": "studio-4377611898-76169",
  "appId": "1:443505989665:web:7040d756a0edfc7e722b60",
  "apiKey": "AIzaSyCUyOgzKzVjS2zFd2Blp74HpSUCLLaBzcY",
  "authDomain": "studio-4377611898-76169.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "443505989665"
};
