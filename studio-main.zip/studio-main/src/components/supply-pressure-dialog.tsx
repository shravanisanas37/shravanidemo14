"use client"

import { useTranslation } from "@/context/language-context"
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription 
} from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { BarChart3, Globe, MapPin, TrendingUp, AlertTriangle } from "lucide-react"

interface SupplyPressureDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  farmerLocation?: string
}

export function SupplyPressureDialog({ open, onOpenChange, farmerLocation }: SupplyPressureDialogProps) {
  const { t } = useTranslation()

  const supplyData = [
    { 
      label: t('supply_local_level'), 
      value: 35, 
      status: t('supply_status_low'), 
      icon: <MapPin className="w-5 h-5 text-primary" />,
      desc: `Supply in ${farmerLocation || 'your region'} is currently below historical averages due to unseasonal rain, creating high price potential for early harvests.`
    },
    { 
      label: t('supply_global_level'), 
      value: 68, 
      status: t('supply_status_med'), 
      icon: <Globe className="w-5 h-5 text-accent" />,
      desc: "International markets are well-stocked for staples, but there is an 18% deficit in organic high-grade produce for the European market."
    }
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl bg-background border-black/10 rounded-[3rem] p-0 overflow-hidden shadow-2xl">
        <DialogHeader className="p-8 pb-4 bg-primary/5">
          <div className="flex items-center gap-4">
            <div className="bg-primary/10 p-3 rounded-2xl">
              <BarChart3 className="w-8 h-8 text-primary" />
            </div>
            <div>
              <DialogTitle className="text-3xl font-black text-foreground tracking-tighter uppercase">
                {t('supply_dialog_title')}
              </DialogTitle>
              <DialogDescription className="text-foreground/60 font-medium">
                Live monitoring of regional and international supply saturation.
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <ScrollArea className="p-8 pt-4">
          <div className="space-y-8 pb-4">
            {supplyData.map((item, idx) => (
              <div key={idx} className="space-y-6 p-6 rounded-[2rem] bg-black/[0.03] border border-black/5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-white rounded-lg shadow-sm">{item.icon}</div>
                    <h3 className="font-black text-foreground uppercase tracking-tight">{item.label}</h3>
                  </div>
                  <Badge variant="outline" className="border-primary/20 bg-primary/5 text-primary font-black uppercase text-[10px]">
                    {item.value}% Saturation
                  </Badge>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-foreground/40">
                    <span>Current Pool</span>
                    <span className={item.value > 70 ? 'text-destructive' : 'text-primary'}>{item.status}</span>
                  </div>
                  <Progress value={item.value} className="h-3 bg-white" />
                </div>

                <p className="text-sm text-foreground/60 font-medium leading-relaxed italic border-l-2 border-primary/20 pl-4">
                  {item.desc}
                </p>
              </div>
            ))}

            <div className="p-6 rounded-[2rem] bg-accent/5 border border-accent/20 flex items-start gap-4">
              <AlertTriangle className="w-6 h-6 text-accent shrink-0 mt-1" />
              <div>
                <h4 className="font-black text-accent uppercase text-xs mb-1">Strategic Advice</h4>
                <p className="text-sm text-foreground/70 leading-relaxed">
                  Focus on early-variety crops for the local market to capitalize on current low supply before the peak harvest season begins.
                </p>
              </div>
            </div>
          </div>
        </ScrollArea>

        <div className="p-6 border-t border-black/5 bg-secondary/10 flex justify-center">
          <button 
            onClick={() => onOpenChange(false)}
            className="text-foreground/40 font-black uppercase tracking-widest text-xs hover:text-foreground transition-colors"
          >
            {t('common_close')}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  )
}