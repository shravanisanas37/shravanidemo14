"use client"

import Link from "next/link"
import { Sprout, Twitter, Linkedin, Github, Mail, Globe } from "lucide-react"

const footerLinks = {
  platform: [
    { label: "Dashboard", href: "/dashboard" },
    { label: "AI Assistant", href: "/chat" },
    { label: "Recommendations", href: "/recommendations" },
  ],
  company: [
    { label: "About Us", href: "/about" },
    { label: "Profile", href: "/profile" },
    { label: "Contact", href: "#" },
    { label: "Privacy Policy", href: "#" },
  ],
  socials: [
    { label: "Twitter", href: "#", icon: Twitter },
    { label: "LinkedIn", href: "#", icon: Linkedin },
    { label: "GitHub", href: "#", icon: Github },
  ],
}

export function Footer() {
  return (
    <footer className="relative z-10 bg-card/30 backdrop-blur-2xl border-t border-white/5 pt-24 pb-12 overflow-hidden">
      {/* Background Ambience */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-px bg-gradient-to-r from-transparent via-accent/20 to-transparent" />
      <div className="absolute -bottom-24 left-1/2 -translate-x-1/2 w-[60%] h-48 bg-primary/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand Column */}
          <div className="space-y-6">
            <Link href="/" className="flex items-center gap-2 group w-fit">
              <div className="bg-primary/20 p-2 rounded-xl border border-accent/20 group-hover:rotate-12 transition-transform">
                <Sprout className="w-8 h-8 text-accent" aria-hidden="true" />
              </div>
              <span className="font-bold text-2xl text-accent font-headline tracking-tighter">AgriVision AI</span>
            </Link>
            <p className="text-muted-foreground text-sm leading-relaxed max-w-xs text-wrap-pretty">
              Empowering global agriculture through planetary intelligence and accessible Generative AI for every farmer.
            </p>
            <div className="flex gap-4">
              {footerLinks.socials.map((social) => (
                <Link 
                  key={social.label} 
                  href={social.href}
                  className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-muted-foreground hover:text-accent hover:border-accent/50 transition-[transform,color,border-color] hover:-translate-y-1 focus-visible:ring-2 focus-visible:ring-accent/50"
                  aria-label={`Follow us on ${social.label}`}
                >
                  <social.icon className="w-5 h-5" aria-hidden="true" />
                </Link>
              ))}
            </div>
          </div>

          {/* Platform Column */}
          <div className="space-y-6">
            <h4 className="text-white font-bold uppercase tracking-widest text-xs">Platform</h4>
            <ul className="space-y-4">
              {footerLinks.platform.map((link) => (
                <li key={link.label}>
                  <Link href={link.href} className="text-muted-foreground hover:text-accent transition-colors text-sm focus-visible:ring-1 focus-visible:ring-accent/50 rounded">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Column */}
          <div className="space-y-6">
            <h4 className="text-white font-bold uppercase tracking-widest text-xs">Company</h4>
            <ul className="space-y-4">
              {footerLinks.company.map((link) => (
                <li key={link.label}>
                  <Link href={link.href} className="text-muted-foreground hover:text-accent transition-colors text-sm focus-visible:ring-1 focus-visible:ring-accent/50 rounded">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Column */}
          <div className="space-y-6">
            <h4 className="text-white font-bold uppercase tracking-widest text-xs">Get in Touch</h4>
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <Mail className="w-4 h-4 text-accent" aria-hidden="true" />
                <span>support@agrivision.ai</span>
              </div>
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <Globe className="w-4 h-4 text-accent" aria-hidden="true" />
                <span>Available in 5+ Languages</span>
              </div>
              <div className="pt-4">
                <div className="p-4 rounded-2xl bg-accent/5 border border-accent/10">
                  <p className="text-[10px] text-accent font-bold uppercase tracking-tighter mb-1">Status</p>
                  <div className="flex items-center gap-2" aria-live="polite">
                    <span className="flex h-2 w-2 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                    </span>
                    <span className="text-xs text-white">All systems operational</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-xs text-muted-foreground font-medium uppercase tracking-widest">
          <p>© 2024 AgriVision AI Inc. All rights reserved.</p>
          <div className="flex gap-8">
            <Link href="#" className="hover:text-white transition-colors focus-visible:ring-1 focus-visible:ring-white/50 rounded">Security</Link>
            <Link href="#" className="hover:text-white transition-colors focus-visible:ring-1 focus-visible:ring-white/50 rounded">Terms</Link>
            <Link href="#" className="hover:text-white transition-colors focus-visible:ring-1 focus-visible:ring-white/50 rounded">Cookies</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
