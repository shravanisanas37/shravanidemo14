"use client"

import { useTranslation } from "@/context/language-context"
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription 
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { CalendarDays, Sparkles, TrendingUp, Info } from "lucide-react"

interface Festival {
  name: string
  date: string
  crops: string[]
  multiplier: string
  description: string
}

const HINDU_FESTIVALS: Festival[] = [
  {
    name: "Ganesh Chaturthi",
    date: "Aug 27, 2025",
    crops: ["Marigold", "Rose", "Banana", "Coconut"],
    multiplier: "2-5x",
    description: "Peak demand for flowers and puja essentials in Maharashtra and South India."
  },
  {
    name: "Navratri",
    date: "Sept 22, 2025",
    crops: ["Chrysanthemum", "Marigold", "Sabudana", "Fruits"],
    multiplier: "1.5-3x",
    description: "Sustained high demand for flowers and specific fasting vegetables."
  },
  {
    name: "Dussehra",
    date: "Oct 2, 2025",
    crops: ["Marigold Garlands", "Sugarcane", "Banana"],
    multiplier: "1.5-2x",
    description: "Pan-India demand spike for puja-related produce."
  },
  {
    name: "Diwali",
    date: "Oct 20, 2025",
    crops: ["Marigold", "Rose", "Lotus", "Mango Leaves", "Dry Fruits"],
    multiplier: "2-4x",
    description: "The largest single demand spike in the Indian agricultural calendar."
  },
  {
    name: "Chhath Puja",
    date: "Oct 27, 2025",
    crops: ["Sugarcane", "Banana", "Ginger", "Turmeric", "Radish"],
    multiplier: "3-5x",
    description: "Extremely high local demand in Bihar, UP, and Jharkhand."
  },
  {
    name: "Makar Sankranti",
    date: "Jan 14, 2026",
    crops: ["Sugarcane", "Turmeric", "Kolam Rice", "Groundnut"],
    multiplier: "2-3x",
    description: "Harvest festival demand for regional staples and puja plants."
  },
  {
    name: "Holi",
    date: "March 3, 2026",
    crops: ["Tesu Flowers", "Wheat", "Mustard", "Herbs"],
    multiplier: "1.5-2x",
    description: "Demand for natural dyes and seasonal Rabi harvest grains."
  },
  {
    name: "Gudi Padwa / Ugadi",
    date: "March 19, 2026",
    crops: ["Raw Mango", "Neem Flowers", "Jaggery", "Banana"],
    multiplier: "2x",
    description: "New Year demand for traditional recipes and puja essentials."
  }
]

interface HinduCalendarProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function HinduCalendar({ open, onOpenChange }: HinduCalendarProps) {
  const { t } = useTranslation()

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl bg-[#f6f09f] border-black/10 rounded-[3rem] p-0 overflow-hidden shadow-2xl">
        <DialogHeader className="p-8 pb-4 bg-primary/5">
          <div className="flex items-center gap-4">
            <div className="bg-primary/10 p-3 rounded-2xl">
              <CalendarDays className="w-8 h-8 text-primary" />
            </div>
            <div>
              <DialogTitle className="text-3xl font-black text-foreground tracking-tighter uppercase">
                {t('festival_calendar_title')}
              </DialogTitle>
              <DialogDescription className="text-foreground/60 font-medium">
                Strategic demand multipliers for the upcoming cycle (2025-2026).
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <ScrollArea className="h-[60vh] p-8 pt-4">
          <div className="space-y-6 pb-8">
            <h3 className="text-xs font-black uppercase tracking-[0.3em] text-primary/60 flex items-center gap-2 mb-4">
              <Sparkles className="w-4 h-4" /> {t('festival_upcoming')}
            </h3>

            {HINDU_FESTIVALS.map((festival, idx) => (
              <div 
                key={idx} 
                className="p-6 rounded-[2rem] bg-white/40 border border-black/5 hover:bg-white/60 transition-all group"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                  <div>
                    <h4 className="text-xl font-black text-foreground tracking-tight uppercase">{festival.name}</h4>
                    <p className="text-sm font-bold text-primary font-variant-numeric-tabular-nums">{festival.date}</p>
                  </div>
                  <Badge className="bg-accent text-background px-4 py-2 rounded-xl flex items-center gap-2 self-start md:self-center font-black">
                    <TrendingUp className="w-4 h-4" /> {festival.multiplier} {t('festival_demand_impact')}
                  </Badge>
                </div>

                <div className="space-y-4">
                  <div className="flex flex-wrap gap-2">
                    {festival.crops.map((crop, cidx) => (
                      <Badge key={cidx} variant="outline" className="border-primary/20 bg-primary/5 text-primary text-[10px] font-black uppercase">
                        {crop}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="flex items-start gap-3 p-4 rounded-xl bg-black/[0.03] text-sm text-foreground/70 font-medium leading-relaxed italic">
                    <Info className="w-4 h-4 shrink-0 text-primary mt-0.5" />
                    “{festival.description}”
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="p-6 border-t border-black/5 bg-primary/5 flex justify-center">
          <button 
            onClick={() => onOpenChange(false)}
            className="text-foreground/40 font-black uppercase tracking-widest text-xs hover:text-foreground transition-colors"
          >
            {t('common_close')}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
