'use client';

import { useEffect } from 'react';

/**
 * Initializes the Google Translate element.
 * This is hidden from view as we use our own custom selector in the Navbar.
 */
export function GoogleTranslate() {
  useEffect(() => {
    // Add the Google Translate script to the body
    const script = document.createElement('script');
    script.src = '//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
    script.async = true;
    document.body.appendChild(script);

    // Initialize the element when the script loads
    (window as any).googleTranslateElementInit = () => {
      new (window as any).google.translate.TranslateElement(
        {
          pageLanguage: 'en',
          includedLanguages: 'en,hi,mr,te,ta',
          autoDisplay: false,
        },
        'google_translate_element'
      );
    };
  }, []);

  return <div id="google_translate_element" style={{ display: 'none' }} />;
}
