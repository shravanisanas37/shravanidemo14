"use client"

import Link from "next/link"
import { MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { usePathname } from "next/navigation"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

/**
 * A floating action button that provides quick access to the AI Chatbot.
 * Features a frosted glass effect without the intrusive notification pulse.
 */
export function ChatFloatingButton() {
  const pathname = usePathname()
  
  if (pathname === "/chat") return null

  return (
    <div className="fixed bottom-8 right-8 z-[100] animate-fade-in">
      <TooltipProvider delayDuration={300}>
        <Tooltip>
          <TooltipTrigger asChild>
            <Link href="/chat" className="relative block group">
              <Button 
                size="icon" 
                className="h-20 w-20 rounded-full shadow-[0_20px_50px_-10px_rgba(234,179,8,0.4)] bg-white/10 backdrop-blur-2xl border-2 border-white/20 text-accent hover:bg-white/20 transition-all hover:scale-110 active:scale-95"
              >
                <MessageCircle className="h-10 w-10" />
              </Button>
            </Link>
          </TooltipTrigger>
          <TooltipContent side="left" className="bg-accent text-accent-foreground border-none font-black py-3 px-6 rounded-2xl mb-4 mr-4 shadow-2xl uppercase tracking-widest text-[10px]">
            Personalized Farm Advice
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  )
}
