"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter, usePathname } from "next/navigation"
import { useAuth, useUser, useFirestore, useDoc, useMemoFirebase } from "@/firebase"
import { doc } from "firebase/firestore"
import { signOut } from "firebase/auth"
import { 
  Sprout, 
  LayoutDashboard, 
  MessageCircle, 
  User, 
  LogOut, 
  Info, 
  Menu, 
  X,
  Search,
  Languages,
  Home,
  Plus
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"
import { motion, AnimatePresence } from "framer-motion"
import { useTranslation } from "@/context/language-context"
import { Language } from "@/lib/translations"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

export function Navbar() {
  const router = useRouter()
  const pathname = usePathname()
  const auth = useAuth()
  const { user } = useUser()
  const db = useFirestore()
  const { t, language, setLanguage } = useTranslation()
  
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  const navLinks = [
    { href: "/", label: t('nav_home'), icon: Home },
    { href: "/dashboard", label: t('nav_dashboard'), icon: LayoutDashboard },
    { href: "/chat", label: t('nav_chat'), icon: MessageCircle },
    { href: "/about", label: t('nav_about'), icon: Info },
  ]

  const userDocRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return doc(db, "users", user.uid)
  }, [db, user])
  const { data: userData } = useDoc(userDocRef)

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const handleLogout = async () => {
    try {
      await signOut(auth)
      router.push("/")
    } catch (error) {
      console.error("Logout failed", error)
    }
  }

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/recommendations?q=${encodeURIComponent(searchQuery.trim())}`)
      setSearchQuery("")
      setIsMobileMenuOpen(false)
    }
  }

  const handleLanguageChange = async (lang: Language) => {
    await setLanguage(lang);
    const langMap: Record<string, string> = {
      English: 'en',
      Hindi: 'hi',
      Marathi: 'mr',
      Telugu: 'te',
      Tamil: 'ta'
    };
    const code = langMap[lang] || 'en';
    document.cookie = `googtrans=/en/${code}; path=/`;
    document.cookie = `googtrans=/en/${code}; path=/; domain=${window.location.hostname}`;
    window.location.reload();
  }

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-[background-color,border-color,shadow] duration-300 px-8 flex items-center justify-between",
        "h-20",
        isScrolled 
          ? "bg-background/80 backdrop-blur-xl border-b border-black/5 shadow-lg" 
          : "bg-transparent"
      )}
    >
      <div className="container mx-auto flex items-center justify-between gap-12">
        <Link href="/" className="flex items-center gap-2 group shrink-0">
          <div className="bg-primary p-1.5 rounded-lg shadow-lg shadow-primary/20 transition-transform group-hover:rotate-12">
            <Sprout className="w-6 h-6 text-background" aria-hidden="true" />
          </div>
          <span className="font-bold text-xl text-foreground font-headline tracking-tighter text-wrap-balance text-gradient">AgriVision AI</span>
        </Link>
        
        <div className="hidden lg:flex items-center gap-2">
          {navLinks.map((link) => (
            <Link 
              key={link.href} 
              href={link.href} 
              className={cn(
                "text-sm font-bold transition-[background-color,color] flex items-center gap-2 py-2.5 px-5 rounded-xl",
                pathname === link.href 
                  ? "bg-primary/10 text-primary" 
                  : "text-foreground/60 hover:text-foreground hover:bg-black/5"
              )}
            >
              <link.icon className="w-4 h-4" aria-hidden="true" />
              {link.label}
            </Link>
          ))}
        </div>

        <div className="hidden md:flex flex-1 max-w-sm relative group">
          <form onSubmit={handleSearchSubmit} className="relative w-full">
            <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
              <Search className="w-4 h-4 text-foreground/30" aria-hidden="true" />
            </div>
            <label htmlFor="nav-search" className="sr-only">Search strategy…</label>
            <input 
              id="nav-search"
              name="search"
              type="text" 
              autoComplete="off"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search strategy…" 
              className="w-full bg-black/5 border border-black/10 rounded-xl py-2.5 pl-11 pr-4 text-sm font-medium text-foreground placeholder:text-foreground/30 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/20 transition-[box-shadow,border-color] shadow-inner"
            />
          </form>
        </div>

        <div className="flex items-center gap-4 shrink-0">
          <div className="hidden sm:block">
            <Select value={language} onValueChange={(v: Language) => handleLanguageChange(v)}>
              <SelectTrigger className="w-[120px] h-10 bg-black/5 border-black/10 rounded-xl font-bold text-foreground text-xs focus-visible:ring-2 focus-visible:ring-primary/20" aria-label="Select language">
                <Languages className="w-4 h-4 mr-2 text-primary" aria-hidden="true" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-card border-black/10 text-foreground">
                <SelectItem value="English">English</SelectItem>
                <SelectItem value="Hindi">Hindi</SelectItem>
                <SelectItem value="Marathi">Marathi</SelectItem>
                <SelectItem value="Telugu">Telugu</SelectItem>
                <SelectItem value="Tamil">Tamil</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {user && (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href="/sowing/new">
                    <Button 
                      variant="outline" 
                      size="icon" 
                      className="rounded-full border-primary/20 bg-primary/5 text-primary hover:bg-primary hover:text-background transition-all shadow-md"
                    >
                      <Plus className="w-5 h-5" />
                    </Button>
                  </Link>
                </TooltipTrigger>
                <TooltipContent className="bg-primary text-background border-none text-[10px] font-black uppercase tracking-widest">
                  {t('dash_new_rec')}
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          )}

          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button 
                  className="flex items-center gap-3 cursor-pointer p-1 rounded-xl hover:bg-black/5 transition-colors focus-visible:ring-2 focus-visible:ring-primary/20"
                  aria-label="User menu"
                >
                  <Avatar className="h-9 w-9 border border-black/10 shadow-lg">
                    <AvatarFallback className="bg-primary text-background text-xs font-black">
                      {userData?.fullName?.[0]?.toUpperCase() || 'U'}
                    </AvatarFallback>
                  </Avatar>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 bg-card border-black/10 rounded-2xl mt-4 p-2 shadow-2xl">
                <DropdownMenuLabel className="px-4 py-3">
                  <p className="text-xs font-bold text-foreground leading-none truncate">{userData?.fullName || "Farmer"}</p>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-widest mt-1 truncate">{userData?.role || "Guest"}</p>
                </DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-black/5" />
                <DropdownMenuItem asChild>
                  <Link href="/profile" className="flex items-center gap-3 p-3 cursor-pointer font-medium text-sm text-foreground/70 hover:text-foreground hover:bg-black/5 rounded-xl transition-colors">
                    <User className="w-4 h-4" aria-hidden="true" /> {t('nav_profile')}
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/sowing/new" className="flex items-center gap-3 p-3 cursor-pointer font-medium text-sm text-foreground/70 hover:text-foreground hover:bg-black/5 rounded-xl transition-colors">
                    <Plus className="w-4 h-4" aria-hidden="true" /> {t('dash_new_rec')}
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-black/5" />
                <DropdownMenuItem 
                  className="flex items-center gap-3 p-3 cursor-pointer text-red-600 font-medium text-sm hover:bg-red-50 rounded-xl transition-colors"
                  onClick={handleLogout}
                >
                  <LogOut className="w-4 h-4" aria-hidden="true" /> {t('nav_logout')}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Link href="/login">
              <Button size="sm" className="bg-primary text-background font-bold rounded-xl px-6 h-10 shadow-lg hover:scale-105 transition-transform">
                Sign In
              </Button>
            </Link>
          )}

          <Button 
            variant="ghost" 
            size="icon" 
            className="lg:hidden text-foreground" 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
          >
            {isMobileMenuOpen ? <X aria-hidden="true" /> : <Menu aria-hidden="true" />}
          </Button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, x: 20 }} 
            animate={{ opacity: 1, x: 0 }} 
            exit={{ opacity: 0, x: 20 }} 
            className="fixed inset-0 top-20 z-40 bg-background/95 backdrop-blur-2xl lg:hidden p-8 flex flex-col gap-4"
          >
            {navLinks.map((link) => (
              <Link 
                key={link.href} 
                href={link.href} 
                onClick={() => setIsMobileMenuOpen(false)} 
                className="text-lg font-bold p-6 rounded-2xl bg-white border border-black/5 shadow-sm flex items-center gap-4 text-foreground"
              >
                <link.icon className="w-6 h-6 text-primary" aria-hidden="true" /> {link.label}
              </Link>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  )
}