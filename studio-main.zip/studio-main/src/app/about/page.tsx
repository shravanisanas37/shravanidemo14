"use client"

import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Sprout, Target, Zap, Globe, ShieldCheck, Map, BarChart4, ArrowRight, Users, Sparkles } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"

const fadeInUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.8, ease: "easeOut" }
}

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
}

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Cinematic Background Elements */}
      <div className="fixed inset-0 z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-primary/20 rounded-full blur-[120px] animate-pulse-slow" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-accent/10 rounded-full blur-[120px] animate-pulse-slow [animation-delay:2s]" />
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none" />
        <div className="absolute inset-0 bg-mesh-grid opacity-10" />
      </div>

      <Navbar />
      
      <main className="relative z-10 pt-24 pb-20">
        {/* Hero Section */}
        <section className="container mx-auto px-6 mb-32 text-center">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-6 py-2 rounded-full glassmorphism text-accent text-xs font-bold uppercase tracking-[0.2em] mb-10 border border-accent/20"
          >
            <Sparkles className="w-4 h-4 animate-pulse" />
            The Future of Agriculture
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="text-6xl md:text-8xl font-bold font-headline mb-8 tracking-tighter leading-tight"
          >
            Cultivating <span className="bg-gradient-to-r from-accent via-white to-primary bg-clip-text text-transparent">Intelligence.</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed font-light"
          >
            AgriVision AI isn't just a platform; it's a paradigm shift. We merge planetary data with 
            Generative AI to empower every farmer on Earth.
          </motion.p>
        </section>

        {/* Vision Section */}
        <section className="container mx-auto px-6 mb-40">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative aspect-square lg:aspect-video rounded-[3rem] overflow-hidden shadow-[0_0_80px_-20px_rgba(34,197,94,0.3)]"
            >
              <Image 
                src="https://picsum.photos/seed/about-vision/1200/800" 
                alt="Our Vision" 
                fill 
                className="object-cover"
                data-ai-hint="sustainable farm technology"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-background/20 to-transparent" />
              <div className="absolute bottom-10 left-10 right-10 p-8 glassmorphism rounded-3xl border-white/10">
                <div className="flex items-center gap-4 mb-2">
                  <div className="bg-primary p-2 rounded-xl">
                    <Target className="w-6 h-6 text-accent" />
                  </div>
                  <span className="font-bold text-white text-xl">Our Mission</span>
                </div>
                <p className="text-sm text-muted-foreground">To achieve global food security through localized intelligence.</p>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="space-y-8"
            >
              <h2 className="text-4xl md:text-5xl font-bold font-headline text-white tracking-tighter">
                Bridging the Gap Between <span className="text-primary italic">Data</span> and <span className="text-accent italic">Dirt.</span>
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Traditional farming relies on intuition and history. AgriVision AI introduces 
                predictive precision. By analyzing soil moisture, satellite thermal imaging, 
                and global market fluctuations, we provide a 360° view of your farm's potential.
              </p>
              
              <div className="grid grid-cols-2 gap-6">
                <div className="p-6 rounded-3xl glassmorphism border-white/5 hover:border-accent/30 transition-all group cursor-default">
                  <Globe className="w-10 h-10 text-accent mb-4 group-hover:scale-110 transition-transform" />
                  <h4 className="font-bold text-white text-lg">Hyper-Local</h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">Advice tailored to your exact coordinates and soil profile.</p>
                </div>
                <div className="p-6 rounded-3xl glassmorphism border-white/5 hover:border-primary/30 transition-all group cursor-default">
                  <Users className="w-10 h-10 text-primary mb-4 group-hover:scale-110 transition-transform" />
                  <h4 className="font-bold text-white text-lg">Accessible</h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">Multi-lingual support ensures no farmer is left behind.</p>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Dynamic How It Works Section */}
        <section className="py-32 bg-secondary/5 relative overflow-hidden mb-40">
          <div className="container mx-auto px-6 relative z-10">
            <motion.div 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="text-center mb-24"
            >
              <h2 className="text-5xl font-bold font-headline text-accent mb-4 tracking-tighter">The Methodology</h2>
              <p className="text-muted-foreground text-lg">How we turn raw bytes into bountiful harvests.</p>
            </motion.div>
            
            <motion.div 
              variants={staggerContainer}
              initial="initial"
              whileInView="animate"
              viewport={{ once: true }}
              className="grid md:grid-cols-3 gap-12"
            >
              {[
                {
                  icon: <Map className="w-10 h-10 text-accent" />,
                  title: "Planetary Ingestion",
                  desc: "We stream real-time data from multispectral satellites and local IoT sensors to build a live digital twin of your farmland."
                },
                {
                  icon: <Zap className="w-10 h-10 text-primary" />,
                  title: "Gemini Synthesis",
                  desc: "Our GenAI models process millions of data points, simulating thousands of harvest scenarios to find the path of maximum yield."
                },
                {
                  icon: <BarChart4 className="w-10 h-10 text-blue-400" />,
                  title: "Localized Insight",
                  desc: "Complex data is distilled into a simple, multi-lingual report with step-by-step guidance on crops, risk, and timing."
                }
              ].map((step, i) => (
                <motion.div key={i} variants={fadeInUp}>
                  <Card className="bg-card/50 backdrop-blur-md border-white/5 hover:border-accent/40 transition-all group rounded-[3rem] p-4 h-full">
                    <CardContent className="pt-10 text-center space-y-6">
                      <div className="mx-auto w-24 h-24 rounded-[2rem] bg-gradient-to-br from-primary/20 to-accent/10 flex items-center justify-center mb-4 group-hover:rotate-12 transition-transform shadow-xl">
                        {step.icon}
                      </div>
                      <h3 className="text-2xl font-bold text-white tracking-tight">{step.title}</h3>
                      <p className="text-muted-foreground text-sm leading-relaxed pb-6">
                        {step.desc}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </section>

        {/* Enhanced Stats Grid */}
        <section className="container mx-auto px-6 mb-40">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { label: "Precision Rate", value: "98.4%", icon: <Target />, color: "text-accent" },
              { label: "Farmers Empowered", value: "10M+", icon: <Globe />, color: "text-primary" },
              { label: "Yield Increase", value: "+32%", icon: <Zap />, color: "text-yellow-400" },
              { label: "Risk Mitigation", value: "Real-time", icon: <ShieldCheck />, color: "text-blue-400" }
            ].map((stat, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="p-10 rounded-[2.5rem] glassmorphism hover:-translate-y-4 transition-all duration-500 border-white/5 flex flex-col items-center text-center group"
              >
                <div className={`${stat.color} mb-6 group-hover:scale-125 transition-transform duration-500`}>
                  {stat.icon}
                </div>
                <h3 className="text-4xl font-bold text-white mb-2 tracking-tighter">{stat.value}</h3>
                <p className="text-xs text-muted-foreground uppercase tracking-widest font-bold">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* Call to Action */}
        <section className="container mx-auto px-6 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="max-w-5xl mx-auto p-16 md:p-24 rounded-[4rem] glassmorphism border-primary/20 bg-primary/5 relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-64 h-64 bg-accent/20 blur-[100px] rounded-full" />
            <div className="relative z-10">
              <h2 className="text-4xl md:text-6xl font-bold font-headline mb-8 tracking-tighter">The seed of the future is <span className="text-accent italic">already sown.</span></h2>
              <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto font-light">
                Join the global movement toward intelligent, sustainable agriculture. Your first recommendation is waiting.
              </p>
              <Link href="/login">
                <Button className="bg-accent text-accent-foreground hover:bg-accent/90 px-12 py-8 text-xl rounded-2xl font-black shadow-[0_20px_50px_-10px_rgba(234,179,8,0.4)] transition-all hover:scale-105 active:scale-95 group">
                  Get Started <ArrowRight className="ml-3 w-6 h-6 group-hover:translate-x-2 transition-transform" />
                </Button>
              </Link>
            </div>
          </motion.div>
        </section>
      </main>
    </div>
  )
}
