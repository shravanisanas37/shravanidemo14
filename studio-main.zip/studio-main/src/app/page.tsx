
"use client"

import { useState } from 'react';
import Link from 'next/link';
import { 
  ArrowRight, 
  Sprout, 
  Loader2, 
  Globe,
  BarChart3,
  MessageCircle,
  MapPin,
  Star
} from 'lucide-react';
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useUser } from '@/firebase';
import { Card, CardContent } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export default function Home() {
  const { isUserLoading } = useUser();
  const { toast } = useToast();
  const heroImage = PlaceHolderImages.find(img => img.id === 'beautiful-farm-bg') || PlaceHolderImages[0];

  // Dynamic Rating State
  const [displayRating, setDisplayRating] = useState(5.0);
  const [totalVotes, setTotalVotes] = useState(1248);

  const [userRating, setUserRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmitRating = (e: React.FormEvent) => {
    e.preventDefault();
    if (userRating === 0) {
      toast({
        variant: "destructive",
        title: "Rating Required",
        description: "Please select a star rating before submitting.",
      });
      return;
    }
    setIsSubmitting(true);
    
    // Simulate dynamic update of the hero badge
    setTimeout(() => {
      const newTotal = totalVotes + 1;
      const newAvg = ((displayRating * totalVotes) + userRating) / newTotal;
      
      setDisplayRating(Number(newAvg.toFixed(1)));
      setTotalVotes(newTotal);
      setIsSubmitting(false);
      setUserRating(0);
      setComment("");
      
      toast({
        title: "Feedback Received",
        description: "Your rating has been integrated into our community metrics!",
      });
      
      // Smooth scroll to top to see the update
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 1000);
  };

  if (isUserLoading) return <div className="min-h-screen flex items-center justify-center bg-background"><Loader2 className="animate-spin text-primary" aria-label="Loading…" /></div>

  return (
    <div className="flex flex-col min-h-screen bg-background text-foreground overflow-x-hidden relative bg-mesh">
      <header className="fixed top-0 w-full z-50 glassmorphism px-8 h-20 flex items-center justify-between border-b border-black/[0.05]">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="bg-primary p-1.5 rounded-lg">
            <Sprout className="w-6 h-6 text-background" aria-hidden="true" />
          </div>
          <span className="font-bold text-xl tracking-tighter text-foreground">AgriVision AI</span>
        </Link>
        <div className="flex items-center gap-6">
          <Link href="/about" className="text-sm font-bold text-foreground/60 hover:text-foreground transition-colors">About</Link>
          <Link href="/login" className="text-sm font-bold text-foreground/60 hover:text-foreground transition-colors">Sign In</Link>
          <Link href="/login">
            <Button className="bg-primary text-primary-foreground hover:bg-primary/90 font-bold px-6 rounded-xl shadow-lg shadow-primary/20 transition-transform hover:scale-105 active:scale-95">
              Get Started
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-grow pt-20">
        <section className="relative min-h-[90vh] flex items-center px-8">
          <div className="container mx-auto grid lg:grid-cols-2 gap-16 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-8"
            >
              <div className="space-y-4">
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-black/[0.03] border border-black/[0.05] text-primary text-xs font-black uppercase tracking-widest">
                  <Globe className="w-4 h-4" aria-hidden="true" /> Global Intelligence
                </div>
                
                {/* Dynamic Farmer Rating Badge */}
                <motion.div 
                  key={displayRating}
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="flex items-center gap-3 bg-white/40 backdrop-blur-md w-fit px-4 py-2 rounded-2xl border border-black/5 shadow-sm"
                >
                  <div className="flex items-center gap-0.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star 
                        key={star} 
                        className={cn(
                          "w-4 h-4 transition-colors",
                          star <= Math.round(displayRating) ? "fill-accent text-accent" : "text-black/10"
                        )} 
                        aria-hidden="true" 
                      />
                    ))}
                  </div>
                  <span className="text-[10px] font-black uppercase tracking-widest text-foreground/70">
                    {displayRating.toFixed(1)} Farmer Rating ({totalVotes.toLocaleString()})
                  </span>
                </motion.div>
              </div>

              <h1 className="text-6xl md:text-8xl font-black tracking-tighter leading-[0.9] text-foreground text-wrap-balance uppercase">
                Agriculture is the <span className="text-primary italic">wisest</span> pursuit.
              </h1>
              <p className="text-xl text-foreground/70 max-w-xl leading-relaxed text-pretty font-medium">
                Empowering farmers with satellite-driven analytics and Generative AI to maximize yields and minimize regional risks.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Link href="/login">
                  <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg px-10 py-8 rounded-2xl font-black transition-all hover:scale-105 active:scale-95 shadow-xl shadow-primary/10">
                    Start Your Analysis <ArrowRight className="ml-2 w-5 h-5" aria-hidden="true" />
                  </Button>
                </Link>
                <Link href="/chat">
                  <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 text-sm px-6 py-4 rounded-xl font-black transition-all hover:scale-105 active:scale-95 shadow-xl shadow-accent/10 h-auto">
                    Talk to AgriBot
                  </Button>
                </Link>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1 }}
              className="relative aspect-square lg:aspect-video rounded-[3rem] overflow-hidden shadow-2xl border border-black/[0.05]"
            >
              <Image 
                src={heroImage.imageUrl}
                alt={heroImage.description}
                fill
                className="object-cover"
                priority
                data-ai-hint={heroImage.imageHint}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
              <div className="absolute bottom-8 left-8 right-8 p-6 glassmorphism rounded-2xl">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-primary/20 rounded-xl">
                      <BarChart3 className="text-primary w-6 h-6" aria-hidden="true" />
                    </div>
                    <div>
                      <p className="text-[10px] uppercase tracking-widest text-foreground/40 font-black">Yield Growth</p>
                      <p className="text-xl font-bold text-foreground">+24.8% Average</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] uppercase tracking-widest text-foreground/40 font-black">Region</p>
                    <p className="text-sm font-bold text-foreground flex items-center gap-1 justify-end">
                      <MapPin className="w-3 h-3 text-primary" aria-hidden="true" /> Multi-Regional
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* AgriBot Promo Section */}
        <section className="py-24">
          <div className="container mx-auto px-8">
            <div className="p-12 rounded-[3rem] bg-gradient-to-br from-primary/5 via-primary/[0.01] to-transparent border border-primary/10 relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-80 h-80 bg-primary/5 blur-[120px] rounded-full -mr-32 -mt-32" />
              <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-12">
                <div className="space-y-6 max-w-xl">
                  <div className="w-16 h-16 rounded-2xl bg-black/[0.03] border border-black/[0.05] flex items-center justify-center animate-float">
                    <MessageCircle className="w-8 h-8 text-primary" aria-hidden="true" />
                  </div>
                  <h2 className="text-3xl md:text-4xl font-black tracking-tighter text-foreground uppercase">Your personal advisor, <span className="text-accent italic">always awake.</span></h2>
                  <p className="text-lg text-foreground/60 font-medium text-pretty">AgriBot speaks English, Hindi, Marathi, and more. Ask about seed selection to harvest timing.</p>
                  <Link href="/chat">
                    <Button className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-xl px-8 h-12 text-sm font-black shadow-lg shadow-accent/10">
                      Talk to AgriBot <ArrowRight className="ml-2 w-5 h-5" aria-hidden="true" />
                    </Button>
                  </Link>
                </div>
                <div className="relative w-full max-w-xs aspect-square">
                  <div className="absolute inset-0 bg-primary/5 blur-3xl rounded-full" />
                  <div className="relative h-full w-full rounded-[2.5rem] border border-black/[0.05] glassmorphism p-6 flex flex-col gap-4 bg-white/60">
                    <div className="bg-black/[0.03] p-4 rounded-xl rounded-tl-none border border-black/[0.05]">
                      <p className="text-[10px] text-primary font-black uppercase tracking-widest mb-1">AgriBot</p>
                      <p className="text-sm text-foreground/80 font-medium">"Wait until Tuesday to sow. Soil moisture will be 12% higher."</p>
                    </div>
                    <div className="bg-primary/5 p-4 rounded-xl rounded-tr-none border border-primary/20 ml-6 shadow-sm">
                      <p className="text-sm text-foreground/90 font-medium">"Perfect. What about organic wheat?"</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Farmer Input Rating Section */}
        <section className="py-24 bg-black/[0.02]">
          <div className="container mx-auto px-8 max-w-4xl">
            <Card className="glassmorphism border-black/5 overflow-hidden rounded-[3rem] shadow-2xl">
              <CardContent className="p-12 md:p-16">
                <div className="text-center space-y-6 mb-12">
                  <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-accent/10 text-accent text-[10px] font-black uppercase tracking-widest border border-accent/20">
                    <Star className="w-3.5 h-3.5 fill-accent" /> Community Voice
                  </div>
                  <h2 className="text-4xl md:text-5xl font-black tracking-tighter text-foreground uppercase leading-tight">Rate Your Experience</h2>
                  <p className="text-lg text-foreground/60 font-medium max-w-xl mx-auto">
                    Your feedback helps us calibrate our AI models to better serve the farming community.
                  </p>
                </div>

                <form onSubmit={handleSubmitRating} className="space-y-10">
                  <div className="flex flex-col items-center gap-4">
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-foreground/40">Select Your Rating</p>
                    <div className="flex gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          className="focus:outline-none transition-transform active:scale-90"
                          onMouseEnter={() => setHoverRating(star)}
                          onMouseLeave={() => setHoverRating(0)}
                          onClick={() => setUserRating(star)}
                        >
                          <Star 
                            className={cn(
                              "w-12 h-12 transition-all duration-300",
                              (hoverRating || userRating) >= star 
                                ? "fill-accent text-accent scale-110 drop-shadow-[0_0_10px_rgba(234,179,8,0.3)]" 
                                : "text-black/10 scale-100"
                            )} 
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-foreground/40 ml-1">Additional Comments</p>
                    <Textarea 
                      placeholder="Tell us how AgriVision AI helped your farm today..."
                      className="bg-white/50 border-black/10 rounded-2xl py-6 px-6 text-lg min-h-[150px] shadow-inner focus-visible:ring-accent"
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                    />
                  </div>

                  <Button 
                    type="submit" 
                    disabled={isSubmitting}
                    className="w-full bg-accent text-accent-foreground hover:bg-accent/90 h-20 text-xl font-black rounded-2xl shadow-xl shadow-accent/20 transition-all hover:scale-[1.02] active:scale-95"
                  >
                    {isSubmitting ? (
                      <Loader2 className="w-6 h-6 animate-spin mr-2" />
                    ) : (
                      "Submit Feedback"
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
    </div>
  );
}
