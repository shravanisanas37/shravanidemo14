import type {Metadata} from 'next';
import './globals.css';
import { FirebaseClientProvider } from '@/firebase/client-provider';
import { Toaster } from '@/components/ui/toaster';
import { ChatFloatingButton } from '@/components/chat-floating-button';
import { Footer } from '@/components/footer';
import { LanguageProvider } from '@/context/language-context';
import { GoogleTranslate } from '@/components/google-translate';

export const metadata: Metadata = {
  title: 'AgriVision AI - Sustainable Farming Advisor',
  description: 'Empowering farmers with GenAI-powered crop recommendations and risk analysis.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet" />
      </head>
      <body className="font-body antialiased bg-background text-foreground flex flex-col min-h-screen">
        <FirebaseClientProvider>
          <LanguageProvider>
            <div className="flex-grow">
              {children}
            </div>
            <Footer />
            <ChatFloatingButton />
            <Toaster />
            <GoogleTranslate />
          </LanguageProvider>
        </FirebaseClientProvider>
      </body>
    </html>
  );
}
