"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useUser, useFirestore, useDoc, useMemoFirebase } from "@/firebase"
import { doc, collection, serverTimestamp } from "firebase/firestore"
import { addDocumentNonBlocking } from "@/firebase"
import { useToast } from "@/hooks/use-toast"
import { useTranslation } from "@/context/language-context"
import { Sprout, Calendar, LandPlot, Loader2, ArrowLeft, Leaf } from "lucide-react"

// Comprehensive Varieties dataset matching the recommendation engine's core varieties
const CROP_VARIETIES = [
  // Rice
  { id: 'rice-1', crop: 'Rice', variety: 'Basmati 1121', maturity: 140 },
  { id: 'rice-2', crop: 'Rice', variety: 'Sona Masuri', maturity: 118 },
  { id: 'rice-3', crop: 'Rice', variety: 'IR-64', maturity: 108 },
  { id: 'rice-4', crop: 'Rice', variety: 'Kolam', maturity: 110 },
  { id: 'rice-5', crop: 'Rice', variety: 'Pusa Basmati 1', maturity: 145 },
  { id: 'rice-6', crop: 'Rice', variety: 'Swarna', maturity: 130 },
  { id: 'rice-7', crop: 'Rice', variety: 'Jyothi', maturity: 115 },
  { id: 'rice-8', crop: 'Rice', variety: 'Ponni', maturity: 112 },
  { id: 'rice-9', crop: 'Rice', variety: 'Ambemohar', maturity: 107 },
  
  // Wheat
  { id: 'wheat-1', crop: 'Wheat', variety: 'Lokwan', maturity: 120 },
  { id: 'wheat-2', crop: 'Wheat', variety: 'Sharbati', maturity: 125 },
  { id: 'wheat-3', crop: 'Wheat', variety: 'HD-2967', maturity: 130 },
  { id: 'wheat-4', crop: 'Wheat', variety: 'Sonalika', maturity: 110 },
  { id: 'wheat-5', crop: 'Wheat', variety: 'Durum (Khapli)', maturity: 122 },
  
  // Mango
  { id: 'mango-1', crop: 'Mango', variety: 'Alphonso', maturity: 135 },
  { id: 'mango-2', crop: 'Mango', variety: 'Kesar', maturity: 125 },
  { id: 'mango-3', crop: 'Mango', variety: 'Dasheri', maturity: 115 },
  { id: 'mango-4', crop: 'Mango', variety: 'Langra', maturity: 120 },
  { id: 'mango-5', crop: 'Mango', variety: 'Totapuri', maturity: 112 },
  { id: 'mango-6', crop: 'Mango', variety: 'Banganapalli', maturity: 120 },
  
  // Banana
  { id: 'banana-1', crop: 'Banana', variety: 'Grand Naine', maturity: 330 },
  { id: 'banana-2', crop: 'Banana', variety: 'Robusta', maturity: 330 },
  { id: 'banana-3', crop: 'Banana', variety: 'Yelakki', maturity: 330 },
  
  // Onion
  { id: 'onion-1', crop: 'Onion', variety: 'Nashik Red', maturity: 105 },
  { id: 'onion-2', crop: 'Onion', variety: 'White Onion', maturity: 110 },
  { id: 'onion-3', crop: 'Onion', variety: 'Pusa Red', maturity: 115 },
  { id: 'onion-4', crop: 'Onion', variety: 'Agrifound Dark Red', maturity: 105 },
  
  // Tomato
  { id: 'tomato-1', crop: 'Tomato', variety: 'Pusa Ruby', maturity: 70 },
  { id: 'tomato-2', crop: 'Tomato', variety: 'Arka Rakshak', maturity: 75 },
  { id: 'tomato-3', crop: 'Tomato', variety: 'NS-516', maturity: 68 },
  
  // Cotton
  { id: 'cotton-1', crop: 'Cotton', variety: 'Bt Cotton (Bollgard II)', maturity: 165 },
  { id: 'cotton-2', crop: 'Cotton', variety: 'Suraj', maturity: 155 },

  // Corn
  { id: 'corn-1', crop: 'Corn', variety: 'Pioneer 3396', maturity: 110 },
  { id: 'corn-2', crop: 'Corn', variety: 'Kaveri 50', maturity: 105 },

  // Sugarcane
  { id: 'sugarcane-1', crop: 'Sugarcane', variety: 'Co 86032', maturity: 350 },
  { id: 'sugarcane-2', crop: 'Sugarcane', variety: 'Co 0238', maturity: 360 },

  // Soybean
  { id: 'soybean-1', crop: 'Soybean', variety: 'JS 335', maturity: 100 },
  { id: 'soybean-2', crop: 'Soybean', variety: 'JS 9560', maturity: 95 },
  
  // Groundnut
  { id: 'groundnut-1', crop: 'Groundnut', variety: 'TG-37A', maturity: 110 },
  { id: 'groundnut-2', crop: 'Groundnut', variety: 'GG-20', maturity: 115 },
  
  // Flowers
  { id: 'flower-1', crop: 'Flower', variety: 'African Marigold', maturity: 68 },
  { id: 'flower-2', crop: 'Flower', variety: 'Rose (Dutch)', maturity: 105 },
  { id: 'flower-3', crop: 'Flower', variety: 'Jasmine (Madurai Malli)', maturity: 210 },
  { id: 'flower-4', crop: 'Flower', variety: 'Hibiscus', maturity: 180 },
  { id: 'flower-5', crop: 'Flower', variety: 'Chrysanthemum', maturity: 88 },
].sort((a, b) => a.crop.localeCompare(b.crop));

export default function NewSowingPage() {
  const router = useRouter()
  const { user, isUserLoading } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  const { t } = useTranslation()
  
  const [saving, setSaving] = useState(false)
  const [formData, setFormData] = useState({
    varietyId: "",
    area: "",
    sownDate: new Date().toISOString().split('T')[0]
  })

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push("/login")
    }
  }, [user, isUserLoading, router])

  const profileDocRef = useMemoFirebase(() => {
    if (!user || !db) return null
    return doc(db, "users", user.uid, "farmerProfile", "main")
  }, [user, db])
  const { data: farmerProfile } = useDoc(profileDocRef)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !db || !formData.varietyId) return

    setSaving(true)
    const selectedVariety = CROP_VARIETIES.find(v => v.id === formData.varietyId);
    if (!selectedVariety) return;

    // Calculate estimated harvest date
    const harvestDate = new Date(formData.sownDate);
    harvestDate.setDate(harvestDate.getDate() + selectedVariety.maturity);

    try {
      const landsRef = collection(db, "users", user.uid, "lands")
      addDocumentNonBlocking(landsRef, {
        userId: user.uid,
        cropName: selectedVariety.crop,
        variety: selectedVariety.variety,
        area: Number(formData.area),
        sownDate: formData.sownDate,
        harvestDate: harvestDate.toISOString().split('T')[0],
        status: 'active',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      })

      toast({ 
        title: t('sowing_success'),
        description: `Estimated harvest: ${harvestDate.toLocaleDateString()}`
      })
      router.push("/dashboard")
    } catch (error) {
      console.error("Error saving sowing record:", error)
      toast({ variant: "destructive", title: "Failed to save", description: "Please check your connection." })
    } finally {
      setSaving(false)
    }
  }

  if (isUserLoading) return <div className="min-h-screen flex items-center justify-center bg-background"><Loader2 className="animate-spin text-primary" /></div>

  return (
    <div className="min-h-screen bg-background relative overflow-hidden pb-20">
      <Navbar />
      <main className="relative z-10 container mx-auto px-4 pt-32">
        <div className="max-w-2xl mx-auto">
          <Button 
            variant="ghost" 
            onClick={() => router.back()} 
            className="mb-8 rounded-full hover:bg-black/5"
          >
            <ArrowLeft className="w-4 h-4 mr-2" /> Back
          </Button>

          <Card className="border-black/5 shadow-2xl bg-white rounded-[3rem] overflow-hidden border">
            <CardHeader className="text-center p-10 bg-secondary/10">
              <div className="mx-auto bg-primary/5 p-6 rounded-[2.5rem] w-fit border border-primary/10 mb-6 shadow-sm">
                <Leaf className="w-10 h-10 text-primary" />
              </div>
              <CardTitle className="text-4xl font-headline font-black text-foreground tracking-tighter mb-2">
                {t('sowing_title')}
              </CardTitle>
              <CardDescription className="text-lg text-foreground/60 font-medium">
                Log your current field activity to update the regional supply pool.
              </CardDescription>
            </CardHeader>
            
            <CardContent className="p-10 md:p-12">
              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="space-y-4">
                  <Label className="text-xs uppercase tracking-widest font-black text-foreground/50 ml-1">{t('sowing_variety')}</Label>
                  <Select 
                    value={formData.varietyId} 
                    onValueChange={(v) => setFormData(p => ({ ...p, varietyId: v }))}
                  >
                    <SelectTrigger className="bg-black/[0.02] border-black/10 h-16 rounded-2xl text-lg">
                      <div className="flex items-center gap-3">
                        <Sprout className="w-5 h-5 text-primary" />
                        <SelectValue placeholder="Select Variety" />
                      </div>
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border max-h-[400px]">
                      {CROP_VARIETIES.map(v => (
                        <SelectItem key={v.id} value={v.id}>{v.crop} - {v.variety}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <Label className="text-xs uppercase tracking-widest font-black text-foreground/50 ml-1">{t('sowing_area')} ({farmerProfile?.areaUnit || 'acres'})</Label>
                    <div className="relative">
                      <LandPlot className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-primary" />
                      <Input 
                        type="number" 
                        placeholder="Ex: 5" 
                        value={formData.area}
                        onChange={(e) => setFormData(p => ({ ...p, area: e.target.value }))}
                        required 
                        className="bg-black/[0.02] border-black/10 h-16 pl-14 rounded-2xl text-lg shadow-inner" 
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <Label className="text-xs uppercase tracking-widest font-black text-foreground/50 ml-1">{t('sowing_date')}</Label>
                    <div className="relative">
                      <Calendar className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-primary" />
                      <Input 
                        type="date" 
                        value={formData.sownDate}
                        onChange={(e) => setFormData(p => ({ ...p, sownDate: e.target.value }))}
                        required 
                        className="bg-black/[0.02] border-black/10 h-16 pl-14 rounded-2xl text-lg shadow-inner" 
                      />
                    </div>
                  </div>
                </div>

                <Button 
                  type="submit" 
                  disabled={saving || !formData.varietyId}
                  className="w-full bg-primary text-background hover:bg-primary/90 h-20 text-xl rounded-2xl font-black shadow-xl transition-all hover:scale-[1.02] active:scale-95"
                >
                  {saving ? <Loader2 className="animate-spin mr-3" /> : t('sowing_submit')}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
