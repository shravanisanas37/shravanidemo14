
"use client"

import { useState, useEffect, useCallback } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { useUser, useFirestore, useMemoFirebase, useDoc } from "@/firebase"
import { doc } from "firebase/firestore"
import { Navbar } from "@/components/navbar"
import { personalizeCropRecommendation, type CropRecommendationOutput } from "@/ai/flows/crop-recommendation-flow"
import { Card, CardContent, CardHeader, CardTitle, CardFooter, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogTrigger,
} from "@/components/ui/dialog"
import { 
  Sprout, 
  Loader2,
  MapPin,
  Target,
  Clock,
  RefreshCw,
  TrendingUp,
  CalendarDays,
  Gem,
  Dna,
  RotateCw,
  ShieldPlus,
  Coins,
  Brain,
  Store,
  Tag
} from "lucide-react"
import Image from "next/image"
import { useTranslation } from "@/context/language-context"
import { PlaceHolderImages } from "@/lib/placeholder-images"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts'

export default function RecommendationsPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const { user, isUserLoading } = useUser()
  const db = useFirestore()
  const { t, language } = useTranslation()
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<CropRecommendationOutput | null>(null)

  const searchQuery = searchParams.get('q')?.toLowerCase() || ""

  const profileDocRef = useMemoFirebase(() => {
    if (!user || !db) return null
    return doc(db, "users", user.uid, "farmerProfile", "main")
  }, [user, db])
  
  const userDocRef = useMemoFirebase(() => {
    if (!user || !db) return null
    return doc(db, "users", user.uid)
  }, [user, db])

  const { data: farmerProfile, isLoading: isProfileLoading } = useDoc(profileDocRef)
  const { data: userData } = useDoc(userDocRef)

  const getCropImage = (imageId: string) => {
    return PlaceHolderImages.find(img => img.id === imageId)?.imageUrl || PlaceHolderImages[0].imageUrl
  }

  const fetchRecs = useCallback(async () => {
    if (!user || isProfileLoading) return
    
    try {
      setLoading(true)
      const result = await personalizeCropRecommendation({
        farmerName: userData?.fullName || "Farmer",
        language: language || "English",
        landArea: Number(farmerProfile?.totalLandArea) || 1,
        landAreaUnit: farmerProfile?.areaUnit || "acres",
        soilType: farmerProfile?.soilType || "Loamy",
        waterSupply: farmerProfile?.waterSupplyInfo || "moderate",
        budget: Number(farmerProfile?.budget) || 1000,
        budgetCurrency: farmerProfile?.currency || "INR",
        state: farmerProfile?.state || "Maharashtra",
        district: farmerProfile?.district || "Nashik",
        marketChannel: farmerProfile?.marketChannel || "Local",
        riskTolerance: (farmerProfile?.riskTolerance || "medium") as any,
        sowingDate: new Date().toISOString()
      })
      setData(result)
    } catch (e) {
      console.error("Failed to fetch recommendations", e)
    } finally {
      setLoading(false)
    }
  }, [user, farmerProfile, userData, language, isProfileLoading])

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push("/login")
    }
  }, [user, isUserLoading, router])

  useEffect(() => {
    if (user && !isProfileLoading && !data) {
      fetchRecs()
    }
  }, [user, isProfileLoading, fetchRecs, data])

  const filteredRecommendations = data?.recommendations.filter(crop => 
    crop.cropName.toLowerCase().includes(searchQuery) ||
    crop.variety.toLowerCase().includes(searchQuery)
  ) || []

  if (isUserLoading || (!user && !loading)) {
    return <div className="min-h-screen flex items-center justify-center bg-background"><Loader2 className="animate-spin text-accent" aria-label="Loading recommendations…" /></div>
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      <main className="container mx-auto px-4 pt-24 max-w-7xl">
        <header className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-8">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <Badge className="bg-primary/10 text-primary border-primary/20 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2">
                <Target className="w-4 h-4" aria-hidden="true" /> Breed-Level Strategy
              </Badge>
              {farmerProfile?.state && (
                <Badge variant="outline" className="border-black/10 text-foreground/60 text-[10px] uppercase tracking-widest px-4 py-1.5 rounded-full">
                  <MapPin className="w-4 h-4 mr-1" aria-hidden="true" /> {farmerProfile.district}, {farmerProfile.state}
                </Badge>
              )}
            </div>
            <h1 className="text-5xl md:text-6xl font-headline font-bold text-foreground tracking-tighter leading-tight text-wrap-balance">
              {t('rec_title')}
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl font-light leading-relaxed text-wrap-pretty">
              AI-driven synthesis of your budget (₹{farmerProfile?.budget || '0'}), soil type, and regional market sinks.
            </p>
          </div>
          <div className="flex gap-4">
            <Button 
              onClick={fetchRecs} 
              disabled={loading}
              variant="outline" 
              className="border-black/10 bg-white/50 text-[10px] font-black uppercase tracking-widest rounded-2xl h-14 px-8 hover:bg-accent/10 transition-colors"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin mr-3" aria-hidden="true" /> : <RefreshCw className="w-5 h-5 mr-3" aria-hidden="true" />}
              {t('rec_refresh')}
            </Button>
          </div>
        </header>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-40 space-y-10">
            <Loader2 className="w-20 h-20 text-accent animate-spin" aria-hidden="true" />
            <p className="text-foreground font-black text-3xl tracking-tighter">{t('common_loading')}</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredRecommendations.length === 0 ? (
              <div className="col-span-full py-20 text-center space-y-4 border-2 border-dashed rounded-[3rem] border-black/5">
                <p className="text-xl font-black text-foreground/40 uppercase tracking-widest">No matching crops found</p>
                <Button variant="link" onClick={() => router.push('/recommendations')}>Clear Search</Button>
              </div>
            ) : (
              filteredRecommendations.map((crop, idx) => (
                <Card key={`${crop.variety}-${idx}`} className="bg-card border-black/5 overflow-hidden hover:border-accent/40 transition-all group flex flex-col rounded-[2.5rem] shadow-xl relative">
                  <div className="relative h-64 w-full overflow-hidden">
                    <Image 
                      src={getCropImage(crop.imageId)}
                      alt={crop.cropName}
                      fill
                      className="object-cover group-hover:scale-110 transition-transform duration-700"
                      sizes="(max-width: 768px) 100vw, 33vw"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
                    
                    <div className="absolute top-5 right-5">
                      <div className="bg-primary text-primary-foreground font-black px-4 py-2 rounded-2xl shadow-2xl text-lg font-variant-numeric-tabular-nums">
                        {crop.suitabilityScore}% <span className="text-[10px] uppercase tracking-tighter ml-1">Match</span>
                      </div>
                    </div>
                    <div className="absolute bottom-6 left-6 right-6">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className="bg-accent text-accent-foreground text-[8px] font-black uppercase tracking-[0.2em] py-1">
                          {crop.cropName}
                        </Badge>
                      </div>
                      <h3 className="text-3xl font-black text-white tracking-tighter uppercase leading-tight line-clamp-2">{crop.variety}</h3>
                    </div>
                  </div>
                  
                  <CardHeader className="p-8 pb-4">
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="secondary" className="bg-primary/10 text-primary text-[9px] uppercase tracking-widest font-black border-primary/20">
                        <Store className="w-3 h-3 mr-1" /> {crop.primaryMarketSink}
                      </Badge>
                      <Badge variant="secondary" className="bg-accent/10 text-accent text-[9px] uppercase tracking-widest font-black border-accent/20">
                        Target: {crop.targetGrade}
                      </Badge>
                    </div>
                  </CardHeader>

                  <CardContent className="p-8 pt-0 flex-grow space-y-6">
                    <div className="p-4 rounded-2xl bg-black/[0.03] border border-black/5 space-y-2">
                      <p className="text-[9px] font-black uppercase tracking-widest text-foreground/40 mb-2 flex items-center gap-2">
                        <Tag className="w-3 h-3" /> Core Variety Intelligence
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {crop.preferredBreeds.map((breed, bidx) => (
                          <span key={bidx} className="text-[10px] font-bold text-foreground/60 bg-white/50 px-2 py-1 rounded-lg border border-black/5">
                            {breed}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 rounded-2xl bg-black/[0.03] border border-black/5">
                        <p className="text-[9px] uppercase tracking-widest text-muted-foreground font-bold mb-1">Harvest Window</p>
                        <p className="text-xs font-black text-foreground flex items-center gap-2 font-variant-numeric-tabular-nums">
                          <CalendarDays className="w-3.5 h-3.5 text-accent" aria-hidden="true" /> {crop.harvestWindow}
                        </p>
                      </div>
                      <div className="p-4 rounded-2xl bg-black/[0.03] border border-black/5">
                        <p className="text-[9px] uppercase tracking-widest text-muted-foreground font-bold mb-1">Duration</p>
                        <p className="text-xs font-black text-foreground flex items-center gap-2 font-variant-numeric-tabular-nums">
                          <Clock className="w-3.5 h-3.5 text-primary" aria-hidden="true" /> {crop.duration}
                        </p>
                      </div>
                    </div>
                  </CardContent>

                  <CardFooter className="p-8 pt-0">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 rounded-[1.5rem] h-16 font-black uppercase tracking-widest text-xs shadow-2xl shadow-primary/20 transition-all hover:scale-105 active:scale-95">
                          {t('rec_view_analysis')}
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-4xl bg-card border-black/5 rounded-[3rem] p-0 overflow-hidden shadow-2xl">
                        <div className="max-h-[85vh] overflow-y-auto scrollbar-hide overscroll-behavior-contain">
                          <div className="relative h-80 w-full overflow-hidden">
                            <Image 
                              src={getCropImage(crop.imageId)} 
                              alt={crop.cropName} 
                              fill 
                              className="object-cover" 
                              sizes="100vw"
                              priority
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-card via-card/20 to-transparent" />
                            <div className="absolute bottom-10 left-10 right-10">
                              <Badge className="bg-accent text-accent-foreground font-black uppercase tracking-widest mb-2 font-variant-numeric-tabular-nums">Match: {crop.suitabilityScore}%</Badge>
                              <div className="flex flex-col mb-1">
                                 <p className="text-xs font-black text-accent uppercase tracking-[0.3em] mb-1">{crop.cropName}</p>
                                 <DialogTitle className="text-5xl font-black text-foreground tracking-tighter uppercase text-wrap-balance">{crop.variety} Strategy</DialogTitle>
                              </div>
                              <p className="text-foreground/60 font-bold uppercase tracking-widest text-sm mt-2">{crop.cropName} • Targeted for {crop.primaryMarketSink}</p>
                            </div>
                          </div>

                          <div className="p-10 space-y-10">
                            <section className="p-8 rounded-[3rem] bg-accent/5 border border-accent/20 space-y-4">
                              <h4 className="text-xs font-black uppercase tracking-widest text-accent flex items-center gap-2">
                                <Brain className="w-4 h-4" aria-hidden="true" /> Breed-Specific Rationale
                              </h4>
                              <p className="text-lg text-foreground/90 leading-relaxed font-medium text-wrap-pretty">
                                {crop.reasoning}
                              </p>
                              <div className="flex items-center gap-2 text-primary font-black uppercase tracking-tighter text-xl mt-4 font-variant-numeric-tabular-nums">
                                <Coins className="w-6 h-6" aria-hidden="true" /> {crop.estimatedProfitability}
                              </div>
                            </section>

                            <div className="grid md:grid-cols-2 gap-8">
                              <div className="space-y-10">
                                <section className="space-y-4">
                                  <h4 className="text-xs font-black uppercase tracking-widest text-accent flex items-center gap-2">
                                    <Dna className="w-4 h-4" aria-hidden="true" /> High-Yield Varieties
                                  </h4>
                                  <div className="grid grid-cols-1 gap-2">
                                    <div className="p-4 rounded-2xl bg-primary text-primary-foreground font-black flex items-center gap-3">
                                      <Badge className="bg-white/20 text-white border-white/30 h-6 w-6 rounded-full flex items-center justify-center p-0 font-variant-numeric-tabular-nums">★</Badge>
                                      {crop.variety} (Primary)
                                    </div>
                                    {crop.preferredBreeds.map((breed, bidx) => (
                                      <div key={bidx} className="p-4 rounded-2xl bg-black/[0.03] border border-black/5 text-foreground/90 font-bold flex items-center gap-3">
                                        <Badge className="bg-primary/20 text-primary border-primary/30 h-6 w-6 rounded-full flex items-center justify-center p-0 font-variant-numeric-tabular-nums">{bidx + 1}</Badge>
                                        {breed}
                                      </div>
                                    ))}
                                  </div>
                                </section>

                                <section className="space-y-4">
                                  <h4 className="text-xs font-black uppercase tracking-widest text-primary flex items-center gap-2">
                                    <RotateCw className="w-4 h-4" aria-hidden="true" /> Ecological Sequencing (Rotation)
                                  </h4>
                                  <div className="p-6 rounded-[2rem] bg-primary/5 border border-primary/20">
                                    <p className="text-sm text-foreground/80 leading-relaxed italic text-wrap-pretty">
                                      “{crop.rotationStrategy}”
                                    </p>
                                  </div>
                                </section>
                              </div>
                              
                              <div className="space-y-8">
                                <section className="space-y-4">
                                  <h4 className="text-xs font-black uppercase tracking-widest text-foreground/60 flex items-center gap-2">
                                    <TrendingUp className="w-4 h-4" aria-hidden="true" /> Price Prediction
                                  </h4>
                                  <div className="h-[200px] w-full p-4 rounded-[2.5rem] bg-black/[0.03] border border-black/5">
                                    <ResponsiveContainer width="100%" height="100%">
                                      <AreaChart data={crop.priceForecast}>
                                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.05)" vertical={false} />
                                        <XAxis dataKey="month" stroke="#555" fontSize={10} axisLine={false} tickLine={false} />
                                        <YAxis hide />
                                        <Tooltip contentStyle={{ backgroundColor: '#fff', border: 'none', borderRadius: '1rem', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                                        <Area type="monotone" dataKey="price" stroke="#10b981" fill="#10b981" fillOpacity={0.1} strokeWidth={3} />
                                      </AreaChart>
                                    </ResponsiveContainer>
                                  </div>
                                </section>

                                <section className="p-8 rounded-[3rem] bg-black/[0.03] border border-black/5 space-y-6">
                                  <h4 className="text-[10px] font-black uppercase tracking-widest text-foreground/40">Calibrated Risk Score</h4>
                                  <div className="space-y-4">
                                    {[
                                      { label: "Weather", score: crop.riskAnalysis.weatherScore, color: "bg-orange-500" },
                                      { label: "Pest Pressure", score: crop.riskAnalysis.pestScore, color: "bg-green-500" },
                                      { label: "Market Volatility", score: crop.riskAnalysis.marketVolatilityScore, color: "bg-blue-500" },
                                    ].map((risk) => (
                                      <div key={risk.label} className="space-y-2">
                                        <div className="flex justify-between text-[10px] font-bold text-foreground uppercase tracking-widest font-variant-numeric-tabular-nums">
                                          <span>{risk.label}</span>
                                          <span>{risk.score}%</span>
                                        </div>
                                        <Progress value={risk.score} className="h-1.5" />
                                      </div>
                                    ))}
                                  </div>
                                </section>
                              </div>
                            </div>

                            <div className="text-center pt-6">
                              <DialogTrigger asChild>
                                <Button variant="ghost" className="text-muted-foreground hover:text-foreground h-16 px-10 rounded-2xl transition-colors">
                                  {t('common_close')}
                                </Button>
                              </DialogTrigger>
                            </div>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </CardFooter>
                </Card>
              ))
            )}
          </div>
        )}
      </main>
    </div>
  )
}
