"use client"

import { useState, useEffect, useCallback } from "react"
import { useRouter } from "next/navigation"
import { useUser, useDoc, useFirestore, useMemoFirebase, useCollection } from "@/firebase"
import { doc, collection, query, limit, orderBy } from "firebase/firestore"
import { deleteDocumentNonBlocking } from "@/firebase"
import { Navbar } from "@/components/navbar"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { useTranslation } from "@/context/language-context"
import { personalizeCropRecommendation, type CropRecommendationOutput } from "@/ai/flows/crop-recommendation-flow"
import { PlaceHolderImages } from "@/lib/placeholder-images"
import { HinduCalendar } from "@/components/hindu-calendar"
import { SupplyPressureDialog } from "@/components/supply-pressure-dialog"
import { useToast } from "@/hooks/use-toast"
import Image from "next/image"
import { 
  BarChart3, 
  TrendingUp, 
  ShieldAlert, 
  Leaf, 
  CalendarDays,
  Plus,
  Loader2,
  MapPin,
  Sprout,
  Target,
  ChevronRight,
  Trash2,
  ArrowRight
} from "lucide-react"
import Link from "next/link"

export default function Dashboard() {
  const router = useRouter()
  const { user, isUserLoading } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  const { t, language } = useTranslation()
  const [mounted, setMounted] = useState(false)
  const [loadingRecs, setLoadingRecs] = useState(false)
  const [recs, setRecs] = useState<CropRecommendationOutput | null>(null)
  const [isCalendarOpen, setIsCalendarOpen] = useState(false)
  const [isSupplyOpen, setIsSupplyOpen] = useState(false)

  const profileDocRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return doc(db, "users", user.uid, "farmerProfile", "main")
  }, [db, user])

  const landsQuery = useMemoFirebase(() => {
    if (!db || !user) return null
    return query(
      collection(db, "users", user.uid, "lands"), 
      orderBy("createdAt", "desc"),
      limit(5)
    )
  }, [db, user])

  const { data: farmerProfile, isLoading: isProfileLoading } = useDoc(profileDocRef)
  const { data: lands } = useCollection(landsQuery)

  const getCropImage = (imageId: string) => {
    return PlaceHolderImages.find(img => img.id === imageId)?.imageUrl || PlaceHolderImages[0].imageUrl
  }

  const handleDeleteLand = (e: React.MouseEvent, landId: string) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user || !db || !landId) return;
    const landRef = doc(db, "users", user.uid, "lands", landId)
    deleteDocumentNonBlocking(landRef)
    toast({ title: "Record Removed" })
  }

  const fetchRecommendations = useCallback(async () => {
    if (!user || !farmerProfile || isProfileLoading) return;
    try {
      setLoadingRecs(true);
      const result = await personalizeCropRecommendation({
        farmerName: farmerProfile.fullName || "Farmer",
        language: language || "English",
        landArea: Number(farmerProfile.totalLandArea) || 1,
        landAreaUnit: farmerProfile.areaUnit || "acres",
        soilType: farmerProfile.soilType || "Loamy",
        waterSupply: farmerProfile.waterSupplyInfo || "moderate",
        budget: Number(farmerProfile.budget) || 1000,
        budgetCurrency: farmerProfile.currency || "INR",
        state: farmerProfile.state || "Maharashtra",
        district: farmerProfile.district || "Nashik",
        marketChannel: farmerProfile.marketChannel || "Local",
        riskTolerance: (farmerProfile.riskTolerance || "medium") as any,
        sowingDate: new Date().toISOString()
      });
      setRecs(result);
    } catch (e) {
      console.error("Dashboard rec fetch failed", e);
    } finally {
      setLoadingRecs(false);
    }
  }, [user, farmerProfile, language, isProfileLoading]);

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted && !isUserLoading && !user) {
      router.push("/login")
    }
  }, [user, isUserLoading, router, mounted])

  useEffect(() => {
    if (user && farmerProfile && !recs && !loadingRecs && !isProfileLoading) {
      fetchRecommendations();
    }
  }, [user, farmerProfile, fetchRecommendations, recs, loadingRecs, isProfileLoading]);

  if (!mounted || isUserLoading) {
    return <div className="min-h-screen flex items-center justify-center bg-background"><Loader2 className="animate-spin text-primary" /></div>
  }

  const stats = [
    { title: "Net Demand", value: "84% Gap", color: "text-primary", icon: <TrendingUp className="w-6 h-6" /> },
    { title: t('dash_health'), value: farmerProfile?.soilType || "Balanced", color: "text-primary", icon: <Leaf className="w-6 h-6" /> },
    { title: "Supply Pressure", value: "Low", color: "text-primary", icon: <BarChart3 className="w-6 h-6" />, onClick: () => setIsSupplyOpen(true) },
    { title: "Next Festival", value: "Navratri", color: "text-accent", icon: <CalendarDays className="w-6 h-6" />, onClick: () => setIsCalendarOpen(true) }
  ]

  return (
    <div className="min-h-screen bg-background pb-20 bg-mesh">
      <Navbar />
      <main className="container mx-auto px-4 pt-32 max-w-7xl">
        <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Sprout className="w-6 h-6 text-primary" />
              <span className="text-[10px] font-black uppercase tracking-[0.3em] text-primary/80">{t('dash_overview')}</span>
            </div>
            <h1 className="text-5xl md:text-6xl font-headline font-black text-foreground tracking-tighter">
              {farmerProfile?.fullName ? `${t('dash_welcome')}, ${farmerProfile.fullName}` : `${t('dash_welcome')}, Farmer`}
            </h1>
            <div className="flex items-center gap-2 mt-4">
              <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-[10px] text-primary font-black uppercase tracking-widest">
                <MapPin className="w-3 h-3" /> {farmerProfile?.district ? `${farmerProfile.district}, ${farmerProfile.state}` : "Regional Center"}
              </div>
              <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-accent/10 border border-accent/20 text-[10px] text-accent font-black uppercase tracking-widest">
                <Target className="w-3 h-3" /> Harvest-Forward Intel
              </div>
            </div>
          </div>
          <div className="flex gap-4">
            <Link href="/sowing/new">
              <Button size="lg" className="bg-primary text-background hover:bg-primary/90 rounded-[2rem] px-10 h-20 font-black text-xl shadow-2xl uppercase tracking-tighter">
                <Plus className="w-6 h-6 mr-3" /> {t('dash_new_rec')}
              </Button>
            </Link>
          </div>
        </header>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-12">
          {stats.map((stat, i) => (
            <Card key={i} className={`glassmorphism p-4 text-center group transition-all hover:border-primary/40 bg-white/80 ${(stat as any).onClick ? 'cursor-pointer hover:bg-white' : ''}`} onClick={(stat as any).onClick}>
              <CardContent className="pt-8">
                <div className={`mx-auto w-14 h-14 rounded-2xl bg-black/[0.03] flex items-center justify-center mb-6 transition-transform group-hover:scale-110 ${stat.color}`}>
                  {stat.icon}
                </div>
                <p className="text-[10px] font-black uppercase tracking-[0.2em] text-foreground/50 mb-2">{stat.title}</p>
                <p className={`text-2xl font-black ${stat.color} capitalize tracking-tighter`}>{stat.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          <Card className="lg:col-span-2 glassmorphism overflow-hidden bg-white/80">
            <CardHeader className="p-10">
              <CardTitle className="text-3xl font-black flex items-center gap-4 text-foreground uppercase tracking-tighter">
                <CalendarDays className="w-8 h-8 text-primary" /> {t('dash_active_sowing')}
              </CardTitle>
              <CardDescription className="text-foreground/60">Regional supply monitoring.</CardDescription>
            </CardHeader>
            <CardContent className="p-10 pt-0 space-y-6">
              {!lands || lands.length === 0 ? (
                <div className="py-20 text-center border-2 border-dashed border-black/10 rounded-[2rem]">
                  <Sprout className="w-16 h-16 text-black/10 mx-auto mb-4" />
                  <p className="text-foreground/40 font-black uppercase tracking-widest text-xs">No active crops logged</p>
                </div>
              ) : (
                lands.map((land, idx) => (
                  <div key={`${land.id}-${idx}`} className="p-6 rounded-[2rem] bg-black/[0.03] border border-black/5 space-y-4">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-4">
                        <div className="bg-primary/10 p-3 rounded-xl"><Leaf className="w-6 h-6 text-primary" /></div>
                        <div>
                          <p className="font-black text-foreground text-xl uppercase">{land.variety} {land.cropName}</p>
                          <p className="text-[10px] text-foreground/40 font-black uppercase tracking-widest">{land.area} {farmerProfile?.areaUnit || 'acres'}</p>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="text-foreground/20 hover:text-destructive h-8 w-8 rounded-full" onClick={(e) => handleDeleteLand(e, land.id)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </CardContent>
          </Card>

          <Card className="glassmorphism bg-white/80">
            <CardHeader className="p-10 pb-4">
              <CardTitle className="text-3xl font-black flex items-center gap-4 text-foreground uppercase tracking-tighter">
                <ShieldAlert className="w-8 h-8 text-accent" /> {t('dash_risk')}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-10 pt-4 space-y-8">
              <div className="space-y-6">
                {[{ name: 'Weather', score: 25 }, { name: 'Supply', score: 65 }, { name: 'Price', score: 15 }].map((risk) => (
                  <div key={risk.name} className="space-y-2">
                    <div className="flex justify-between text-[10px] font-black uppercase tracking-widest"><span>{risk.name}</span><span>{risk.score}%</span></div>
                    <Progress value={risk.score} className="h-2 bg-black/5" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-1 gap-8 mb-12">
          <Card className="glassmorphism p-6 bg-white/80">
            <CardHeader className="px-6 pt-6 mb-4 flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-3xl font-black text-foreground uppercase tracking-tighter">{t('rec_title')}</CardTitle>
                <CardDescription className="text-primary font-bold text-xs uppercase">Regional Strategic Advantage</CardDescription>
              </div>
              <Link href="/recommendations">
                <Button variant="ghost" size="sm" className="text-primary font-black uppercase tracking-widest text-[10px] hover:bg-primary/5 rounded-xl px-4">
                  View All <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent className="px-6 pb-6 space-y-4">
              {loadingRecs ? (
                <div className="py-20 text-center"><Loader2 className="w-10 h-10 animate-spin text-primary mx-auto" /></div>
              ) : (
                recs?.recommendations.slice(0, 4).map((item, idx) => (
                  <Link key={`${item.variety}-${idx}`} href={`/recommendations?q=${item.cropName}`} className="block">
                    <div className="flex items-center justify-between p-4 rounded-[2rem] border border-black/5 bg-black/[0.03] hover:bg-primary/5 transition-all group cursor-pointer mb-2">
                      <div className="flex items-center gap-4">
                        <div className="relative h-16 w-16 rounded-xl overflow-hidden shrink-0 border border-black/5">
                          <Image src={getCropImage(item.imageId)} alt={item.cropName} fill className="object-cover group-hover:scale-110 transition-transform duration-500" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-black text-foreground text-xl tracking-tighter uppercase">{item.cropName}</p>
                            <Badge className="bg-primary/10 text-primary text-[8px] font-black uppercase">Institutional Demand</Badge>
                          </div>
                          <p className="text-[10px] text-foreground/40 font-black uppercase tracking-[0.2em]">{item.primaryMarketSink}</p>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-foreground/30 group-hover:translate-x-2 transition-transform" />
                    </div>
                  </Link>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      <HinduCalendar open={isCalendarOpen} onOpenChange={setIsCalendarOpen} />
      <SupplyPressureDialog 
        open={isSupplyOpen} 
        onOpenChange={setIsSupplyOpen} 
        farmerLocation={farmerProfile?.district || farmerProfile?.state} 
      />
    </div>
  )
}