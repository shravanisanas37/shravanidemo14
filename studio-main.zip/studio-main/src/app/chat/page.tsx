"use client"

import { useState, useRef, useEffect } from "react"
import { useUser, useFirestore, useCollection, useMemoFirebase, useDoc } from "@/firebase"
import { collection, query, orderBy, limit, serverTimestamp, doc, Timestamp, setDoc } from "firebase/firestore"
import { addDocumentNonBlocking } from "@/firebase"
import { Navbar } from "@/components/navbar"
import { agriculturalAdviceChat } from "@/ai/flows/agricultural-advice-chat-flow"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Send, Bot, User, Loader2, Languages, Sparkles, Sprout, TrendingUp, ShieldAlert, Bug } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { useTranslation } from "@/context/language-context"
import { Language } from "@/lib/translations"

const SUGGESTIONS = [
  { text: "Best crop for my land?", icon: <Sprout className="w-4 h-4" /> },
  { text: "Is onion risky this season?", icon: <ShieldAlert className="w-4 h-4" /> },
  { text: "Should I export tomato?", icon: <TrendingUp className="w-4 h-4" /> },
  { text: "How to manage soil health?", icon: <Sparkles className="w-4 h-4" /> },
  { text: "Pest control for organic farms?", icon: <Bug className="w-4 h-4" /> },
]

function sanitizeForServerAction(obj: any): any {
  if (!obj || typeof obj !== 'object') return obj;
  if (obj instanceof Timestamp) return obj.toDate().toISOString();
  const sanitized = Array.isArray(obj) ? [] : {};
  for (const [key, value] of Object.entries(obj)) {
    if (value instanceof Timestamp) (sanitized as any)[key] = value.toDate().toISOString();
    else if (typeof value === 'object' && value !== null) (sanitized as any)[key] = sanitizeForServerAction(value);
    else (sanitized as any)[key] = value;
  }
  return sanitized;
}

export default function ChatPage() {
  const { user, isUserLoading } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  const { t, language, setLanguage } = useTranslation()
  
  const [input, setInput] = useState("")
  const [isAiThinking, setIsAiThinking] = useState(false)
  const [sessionId, setSessionId] = useState<string | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  const profileDocRef = useMemoFirebase(() => {
    if (!user || !db) return null
    return doc(db, "users", user.uid, "farmerProfile", "main")
  }, [user, db])
  const { data: farmerProfile } = useDoc(profileDocRef)

  useEffect(() => {
    if (user && db && !sessionId) {
      const defaultSessionId = "main-chat-session"
      setSessionId(defaultSessionId)
      const sessionRef = doc(db, "users", user.uid, "aiChatSessions", defaultSessionId)
      setDoc(sessionRef, {
        id: defaultSessionId,
        userId: user.uid,
        startTime: new Date().toISOString(),
        topic: "General Agricultural Advice",
        createdAt: serverTimestamp(),
      }, { merge: true })
    }
  }, [user, sessionId, db])

  const messagesQuery = useMemoFirebase(() => {
    if (!user || !db || !sessionId) return null
    return query(
      collection(db, "users", user.uid, "aiChatSessions", sessionId, "messages"),
      orderBy("timestamp", "asc"),
      limit(50)
    )
  }, [db, user, sessionId])
  const { data: messages, isLoading: isMessagesLoading } = useCollection(messagesQuery)

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollIntoView({ behavior: "smooth" })
  }, [messages, isAiThinking])

  const handleSend = async (textToSend?: string) => {
    const messageText = textToSend || input.trim()
    if (!messageText || isAiThinking || !user || !sessionId || !db) return
    if (!textToSend) setInput("")
    setIsAiThinking(true)
    const messagesRef = collection(db, "users", user.uid, "aiChatSessions", sessionId, "messages")
    addDocumentNonBlocking(messagesRef, {
      sessionId,
      sender: "user",
      messageText: messageText,
      timestamp: new Date().toISOString(),
      createdAt: serverTimestamp()
    })
    try {
      const history = (messages || []).map(m => ({
        role: (m.sender === "ai" ? "model" : "user") as "user" | "model",
        content: m.messageText
      }))
      const sanitizedProfile = sanitizeForServerAction(farmerProfile || { fullName: "Farmer" });
      const aiResponse = await agriculturalAdviceChat({
        message: messageText,
        language: language,
        chatHistory: history,
        farmerProfile: sanitizedProfile,
      })
      addDocumentNonBlocking(messagesRef, {
        sessionId,
        sender: "ai",
        messageText: aiResponse.response,
        timestamp: new Date().toISOString(),
        createdAt: serverTimestamp()
      })
    } catch (e) {
      toast({
        variant: "destructive",
        title: "AgriBot Connection Issue",
        description: "I'm having trouble connecting to my brain. Please try again in a moment.",
      })
    } finally {
      setIsAiThinking(false)
    }
  }

  if (isUserLoading || !user) return <div className="min-h-screen flex items-center justify-center bg-background"><Loader2 className="animate-spin text-accent" /></div>

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Navbar />
      <main className="flex-grow container mx-auto max-w-4xl px-4 pt-24 pb-4 flex flex-col h-[calc(100vh-64px)]">
        <Card className="flex-grow bg-card border-border flex flex-col overflow-hidden shadow-2xl rounded-[2.5rem] glassmorphism">
          <header className="p-6 border-b border-black/5 bg-secondary/30 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="bg-primary/10 p-3 rounded-2xl border border-primary/20">
                <Bot className="w-7 h-7 text-primary" />
              </div>
              <div>
                <h2 className="font-bold text-xl text-foreground tracking-tight">{t('chat_title')}</h2>
                <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground uppercase tracking-[0.2em] font-black">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-500 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-green-600"></span>
                  </span>
                  {t('chat_system_status')}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Select value={language} onValueChange={(v: Language) => setLanguage(v)}>
                <SelectTrigger className="w-[140px] h-10 text-xs bg-background/50 rounded-full border-black/10">
                  <Languages className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  <SelectItem value="English">English</SelectItem>
                  <SelectItem value="Hindi">Hindi (हिन्दी)</SelectItem>
                  <SelectItem value="Marathi">Marathi (मराठी)</SelectItem>
                  <SelectItem value="Telugu">Telugu (తెలుగు)</SelectItem>
                  <SelectItem value="Tamil">Tamil (தமிழ்)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </header>

          <ScrollArea className="flex-grow p-6">
            <div className="space-y-8">
              {messages?.length === 0 && !isMessagesLoading && (
                <div className="flex flex-col items-center justify-center py-20 text-center space-y-10 animate-fade-in">
                  <div className="space-y-6">
                    <div className="bg-primary/5 p-8 rounded-[3rem] mx-auto w-fit border border-primary/10 animate-float">
                      <Sparkles className="w-12 h-12 text-primary" />
                    </div>
                    <div className="space-y-2">
                      <p className="font-black text-foreground text-3xl tracking-tighter">Welcome to AgriBot</p>
                      <p className="text-foreground/60 max-w-sm mx-auto text-lg font-medium leading-relaxed">
                        I can help with crop selection, soil health, and market trends.
                      </p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl w-full">
                    {SUGGESTIONS.map((suggestion, idx) => (
                      <Button
                        key={idx}
                        variant="outline"
                        className="h-auto py-5 px-6 justify-start text-left border-black/5 bg-white hover:bg-primary/5 hover:border-primary/20 transition-all rounded-3xl group shadow-sm"
                        onClick={() => handleSend(suggestion.text)}
                        disabled={isAiThinking}
                      >
                        <div className="flex items-center gap-4">
                          <div className="p-3 rounded-xl bg-primary/5 text-primary group-hover:scale-110 transition-transform">
                            {suggestion.icon}
                          </div>
                          <span className="text-base font-black text-foreground/90 leading-tight">{suggestion.text}</span>
                        </div>
                      </Button>
                    ))}
                  </div>
                </div>
              )}
              {isMessagesLoading && <div className="flex flex-col items-center justify-center py-20"><Loader2 className="w-10 h-10 animate-spin text-accent" /></div>}
              {messages?.map((msg, i) => (
                <div key={msg.id || i} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"}`}>
                  <div className={`flex gap-4 max-w-[80%] ${msg.sender === "user" ? "flex-row-reverse" : "flex-row"}`}>
                    <Avatar className={`h-10 w-10 shrink-0 border ${msg.sender === "user" ? "border-primary/20" : "border-secondary/20"}`}>
                      <AvatarFallback className={msg.sender === "user" ? "bg-primary text-background" : "bg-secondary text-foreground"}>
                        {msg.sender === "user" ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
                      </AvatarFallback>
                    </Avatar>
                    <div className={`p-5 rounded-[2rem] shadow-md ${msg.sender === "user" ? "bg-primary text-background rounded-tr-none" : "bg-white text-foreground border border-black/5 rounded-tl-none"}`}>
                      <p className="text-lg font-medium leading-relaxed whitespace-pre-wrap">{msg.messageText}</p>
                    </div>
                  </div>
                </div>
              ))}
              {isAiThinking && (
                <div className="flex justify-start">
                  <div className="flex gap-4 max-w-[80%]">
                    <Avatar className="h-10 w-10 shrink-0 animate-pulse bg-primary/10" />
                    <div className="bg-white p-5 rounded-[2rem] rounded-tl-none border border-black/5 flex items-center gap-3 shadow-sm">
                      <div className="flex gap-1.5">
                        <span className="w-2 h-2 bg-primary rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                        <span className="w-2 h-2 bg-primary rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                        <span className="w-2 h-2 bg-primary rounded-full animate-bounce"></span>
                      </div>
                      <span className="text-base text-muted-foreground font-bold">AgriBot is analyzing…</span>
                    </div>
                  </div>
                </div>
              )}
              <div ref={scrollRef} className="h-4" />
            </div>
          </ScrollArea>

          <footer className="p-6 border-t border-black/5 bg-secondary/10">
            <form onSubmit={(e) => { e.preventDefault(); handleSend(); }} className="flex gap-4">
              <Input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={t('chat_ask_placeholder')}
                className="bg-white border-black/10 focus-visible:ring-primary py-8 px-6 rounded-[1.5rem] h-16 text-lg shadow-inner"
                disabled={isAiThinking}
              />
              <Button 
                type="submit" 
                className="bg-primary text-background hover:bg-primary/90 shrink-0 h-16 w-16 rounded-[1.5rem] shadow-xl shadow-primary/20 transition-all active:scale-95 disabled:opacity-50"
                disabled={isAiThinking || !input.trim()}
              >
                <Send className="w-7 h-7" />
              </Button>
            </form>
          </footer>
        </Card>
      </main>
    </div>
  )
}