"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useAuth, useUser } from "@/firebase"
import { signInAnonymously } from "firebase/auth"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Sprout, ArrowRight, Loader2, PlayCircle, Lock } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import Image from "next/image"
import { PlaceHolderImages } from "@/lib/placeholder-images"

export default function LoginPage() {
  const router = useRouter()
  const { user, isUserLoading } = useUser()
  const auth = useAuth()
  const { toast } = useToast()
  
  const [step, setStep] = useState<"credentials" | "otp">("credentials")
  const [loading, setLoading] = useState(false)
  const [aadhaar, setAadhaar] = useState("")
  const [mobile, setMobile] = useState("")
  const [otp, setOtp] = useState("")

  const bgImage = PlaceHolderImages.find(img => img.id === 'beautiful-farm-bg');

  useEffect(() => {
    if (!isUserLoading && user) {
      router.push("/dashboard")
    }
  }, [user, isUserLoading, router])

  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault()
    if (aadhaar.length !== 12) {
      toast({ variant: "destructive", title: "Invalid Aadhaar", description: "Please enter a valid 12-digit Aadhaar number." })
      return
    }
    if (mobile.length < 10) {
      toast({ variant: "destructive", title: "Invalid Mobile", description: "Please enter a valid mobile number." })
      return
    }
    setLoading(true)
    // Simulate OTP sending
    setTimeout(() => {
      setLoading(false)
      setStep("otp")
      toast({ title: "OTP Sent", description: "A verification code has been sent to your mobile." })
    }, 1000)
  }

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault()
    if (otp !== "123456") { // Simulated OTP for demo purposes
      toast({ variant: "destructive", title: "Invalid OTP", description: "The code you entered is incorrect. Try 123456 for demo." })
      return
    }
    
    setLoading(true)
    try {
      await signInAnonymously(auth)
      toast({ title: "Login Successful", description: "Welcome back to AgriVision AI." })
      router.push("/dashboard")
    } catch (error) {
      toast({ variant: "destructive", title: "Login Failed", description: "Something went wrong. Please try again." })
    } finally {
      setLoading(false)
    }
  }

  const handleQuickDemo = async () => {
    setLoading(true)
    try {
      await signInAnonymously(auth)
      toast({ title: "Demo Mode Active", description: "Entering as a guest farmer." })
      router.push("/dashboard")
    } catch (error) {
      toast({ variant: "destructive", title: "Demo Login Failed", description: "Could not start demo session." })
    } finally {
      setLoading(false)
    }
  }

  if (isUserLoading) return <div className="min-h-screen flex items-center justify-center bg-background"><Loader2 className="animate-spin text-accent" aria-label="Authenticating…" /></div>

  return (
    <div className="min-h-screen relative flex items-center justify-center p-6 overflow-hidden bg-background">
      {/* Background Ambience */}
      <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] bg-primary/20 rounded-full blur-[120px] animate-pulse-slow" />
        <div className="absolute bottom-[-10%] left-[-10%] w-[50%] h-[50%] bg-accent/10 rounded-full blur-[120px] animate-pulse-slow [animation-delay:2s]" />
      </div>

      <Link href="/" className="absolute top-8 left-8 flex items-center gap-2 z-20 group">
        <div className="bg-primary p-2 rounded-xl shadow-lg shadow-primary/20 transition-transform group-hover:rotate-12">
          <Sprout className="w-8 h-8 text-accent-foreground" aria-hidden="true" />
        </div>
        <span className="font-bold text-2xl text-accent font-headline tracking-tighter">AgriVision AI</span>
      </Link>

      {/* Hero Image Background */}
      <div className="absolute inset-0 z-0">
        {bgImage && (
          <Image 
            src={bgImage.imageUrl}
            alt={bgImage.description}
            fill
            className="object-cover opacity-20 scale-110 blur-sm"
            priority
            data-ai-hint={bgImage.imageHint}
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-br from-background via-background/60 to-transparent" />
      </div>

      <Card className="w-full max-w-md glassmorphism border-black/5 relative z-10 animate-fade-in-up shadow-2xl">
        <CardHeader className="text-center space-y-4 pt-10">
          <div className="mx-auto bg-accent/20 p-5 rounded-[2rem] w-fit border border-accent/30 animate-float">
            <Lock className="w-10 h-10 text-accent" aria-hidden="true" />
          </div>
          <div>
            <CardTitle className="text-4xl font-headline text-foreground tracking-tighter">Secure Access</CardTitle>
            <CardDescription className="text-muted-foreground mt-2">
              {step === "credentials" 
                ? "Enter your details to access your farm analysis." 
                : "Verification code sent to your mobile."}
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="pb-10">
          {step === "credentials" ? (
            <div className="space-y-8">
              <form onSubmit={handleSendOtp} className="space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="aadhaar" className="text-xs uppercase tracking-widest text-muted-foreground ml-1">Aadhaar ID</Label>
                  <Input 
                    id="aadhaar" 
                    name="aadhaar"
                    placeholder="1234 5678 9012" 
                    autoComplete="off"
                    inputMode="numeric"
                    spellCheck={false}
                    value={aadhaar}
                    onChange={(e) => setAadhaar(e.target.value.replace(/\D/g, '').slice(0, 12))}
                    className="bg-white/50 border-black/10 focus:border-accent/50 focus-visible:ring-accent h-14 text-lg rounded-2xl transition-all"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mobile" className="text-xs uppercase tracking-widest text-muted-foreground ml-1">Mobile Number</Label>
                  <div className="flex gap-3">
                    <div className="flex items-center justify-center bg-white/50 px-4 rounded-2xl text-sm font-bold text-muted-foreground border border-black/10">+91</div>
                    <Input 
                      id="mobile" 
                      name="mobile"
                      placeholder="9876543210" 
                      type="tel"
                      autoComplete="tel"
                      inputMode="tel"
                      spellCheck={false}
                      value={mobile}
                      onChange={(e) => setMobile(e.target.value.replace(/\D/g, '').slice(0, 10))}
                      className="bg-white/50 border-black/10 focus:border-accent/50 focus-visible:ring-accent h-14 text-lg rounded-2xl transition-all"
                      required
                    />
                  </div>
                </div>
                <Button type="submit" className="w-full bg-accent text-accent-foreground hover:bg-accent/90 h-16 text-xl font-bold rounded-2xl transition-all active:scale-95 shadow-xl shadow-accent/20" disabled={loading}>
                  {loading ? <Loader2 className="animate-spin mr-2" aria-hidden="true" /> : "Verify Identity"}
                  {!loading && <ArrowRight className="ml-2 w-6 h-6" aria-hidden="true" />}
                </Button>
              </form>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-black/10" />
                </div>
                <div className="relative flex justify-center text-[10px] uppercase tracking-widest font-bold">
                  <span className="bg-background px-4 text-muted-foreground">Or access via</span>
                </div>
              </div>

              <Button 
                variant="outline" 
                className="w-full border-black/10 bg-white/20 text-foreground hover:bg-white/30 h-16 rounded-2xl transition-colors group" 
                onClick={handleQuickDemo}
                disabled={loading}
              >
                <PlayCircle className="mr-3 h-6 w-6 text-accent group-hover:scale-110 transition-transform" aria-hidden="true" />
                Quick Demo Session
              </Button>
            </div>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-8">
              <div className="space-y-4">
                <Label htmlFor="otp" className="text-center block text-xs uppercase tracking-widest text-muted-foreground">One-Time Password</Label>
                <Input 
                  id="otp" 
                  name="otp"
                  placeholder="000000" 
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  spellCheck={false}
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  className="bg-white/50 border-black/10 focus:border-accent/50 focus-visible:ring-accent text-center text-4xl h-20 tracking-[0.5em] font-black rounded-2xl"
                  required
                />
                <p className="text-xs text-center text-muted-foreground">
                  Use <span className="text-accent font-bold">123456</span> for immediate access.
                </p>
              </div>
              <div className="flex flex-col gap-4">
                <Button type="submit" className="w-full bg-accent text-accent-foreground hover:bg-accent/90 h-16 text-xl font-bold rounded-2xl shadow-xl shadow-accent/20 transition-all active:scale-95" disabled={loading}>
                  {loading ? <Loader2 className="animate-spin mr-2" aria-hidden="true" /> : "Verify & Start"}
                </Button>
                <Button variant="ghost" type="button" className="text-muted-foreground hover:text-foreground transition-colors" onClick={() => setStep("credentials")} disabled={loading}>
                  Change details
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  )
}