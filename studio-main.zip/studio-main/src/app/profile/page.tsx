
"use client"

import { useState, useEffect, useRef } from "react"
import { useRouter } from "next/navigation"
import { Navbar } from "@/components/navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { 
  LandPlot, 
  MapPin, 
  Activity, 
  Loader2, 
  User as UserIcon, 
  Briefcase, 
  FileBadge,
  Upload,
  Calendar,
  Trash2,
} from "lucide-react"
import { useUser, useFirestore, useDoc, useMemoFirebase, useCollection } from "@/firebase"
import { doc, setDoc, serverTimestamp, collection, query, orderBy } from "firebase/firestore"
import { addDocumentNonBlocking, deleteDocumentNonBlocking } from "@/firebase"
import { useToast } from "@/hooks/use-toast"
import { useTranslation } from "@/context/language-context"

const STATES = [
  "Andhra Pradesh", "Gujarat", "Haryana", "Karnataka", "Maharashtra", "Punjab", "Tamil Nadu", "Telangana", "Uttar Pradesh"
].sort();

const DISTRICT_MAP: Record<string, string[]> = {
  "Andhra Pradesh": ["Guntur", "Krishna", "Kurnool"],
  "Gujarat": ["Ahmedabad", "Rajkot", "Surat"],
  "Maharashtra": ["Nashik", "Pune", "Kolhapur", "Nagpur", "Ratnagiri"],
  "Karnataka": ["Bengaluru Rural", "Mysuru", "Belgaum"],
  "Punjab": ["Ludhiana", "Amritsar", "Jalandhar"],
  "Uttar Pradesh": ["Lucknow", "Varanasi", "Meerut"],
  "Tamil Nadu": ["Coimbatore", "Thanjavur", "Madurai"],
  "Telangana": ["Hyderabad", "Nizamabad", "Warangal"],
  "Haryana": ["Karnal", "Panipat", "Hisar"]
};

export default function ProfilePage() {
  const router = useRouter()
  const { user, isUserLoading } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  const { t } = useTranslation()
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  const [saving, setSaving] = useState(false)
  const [uploadingCert, setUploadingCert] = useState(false)
  const [newCert, setNewCert] = useState({
    title: "",
    expiryDate: "",
    fileDataUri: "",
    issuer: ""
  })

  const profileDocRef = useMemoFirebase(() => {
    if (!user || !db) return null
    return doc(db, "users", user.uid, "farmerProfile", "main")
  }, [user, db])

  const userDocRef = useMemoFirebase(() => {
    if (!user || !db) return null
    return doc(db, "users", user.uid)
  }, [user, db])

  const certsQuery = useMemoFirebase(() => {
    if (!user || !db) return null
    return query(collection(db, "users", user.uid, "certificates"), orderBy("createdAt", "desc"))
  }, [user, db])

  const { data: farmerProfile, isLoading: isProfileLoading } = useDoc(profileDocRef)
  const { data: userData, isLoading: isUserDataLoading } = useDoc(userDocRef)
  const { data: certificates } = useCollection(certsQuery)

  const [formData, setFormData] = useState({
    name: "",
    language: "English",
    state: "",
    district: "",
    area: "",
    areaUnit: "acres",
    water: "moderate",
    soil: "Loamy",
    risk: "medium",
    budget: "",
    currency: "INR",
    marketChannel: "Local"
  })

  // Synchronize form data with Firestore data when it loads
  useEffect(() => {
    if (farmerProfile || userData) {
      setFormData({
        name: userData?.fullName || farmerProfile?.fullName || "",
        language: farmerProfile?.language || "English",
        state: farmerProfile?.state || "",
        district: farmerProfile?.district || "",
        area: farmerProfile?.totalLandArea?.toString() || "",
        areaUnit: farmerProfile?.areaUnit || "acres",
        water: farmerProfile?.waterSupplyInfo || "moderate",
        soil: farmerProfile?.soilType || "Loamy",
        risk: farmerProfile?.riskTolerance || "medium",
        budget: farmerProfile?.budget?.toString() || "",
        currency: farmerProfile?.currency || "INR",
        marketChannel: farmerProfile?.marketChannel || "Local"
      })
    }
  }, [farmerProfile, userData])

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.push("/login")
    }
  }, [user, isUserLoading, router])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }))
    if (name === "state") {
      setFormData(prev => ({ ...prev, district: "" }))
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      if (file.size > 1024 * 1024) { 
        toast({ variant: "destructive", title: "File too large", description: "Limit 1MB." })
        return
      }
      const reader = new FileReader()
      reader.onloadend = () => setNewCert(prev => ({ ...prev, fileDataUri: reader.result as string }))
      reader.readAsDataURL(file)
    }
  }

  const handleAddCertificate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !db || !newCert.fileDataUri) return
    setUploadingCert(true)
    try {
      const certsRef = collection(db, "users", user.uid, "certificates")
      addDocumentNonBlocking(certsRef, { 
        ...newCert, 
        createdAt: new Date().toISOString() 
      })
      setNewCert({ title: "", expiryDate: "", fileDataUri: "", issuer: "" })
      if (fileInputRef.current) fileInputRef.current.value = ""
      toast({ title: "Certificate Uploaded" })
    } catch (e) {
      toast({ variant: "destructive", title: "Upload Failed" })
    } finally {
      setUploadingCert(false)
    }
  }

  const handleDeleteCertificate = (id: string) => {
    if (!user || !db) return
    const certRef = doc(db, "users", user.uid, "certificates", id)
    deleteDocumentNonBlocking(certRef)
    toast({ title: "Certificate Removed" })
  }

  const handleSubmitProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !db) return
    setSaving(true)
    try {
      // Save basic user info
      const userRef = doc(db, "users", user.uid)
      await setDoc(userRef, { 
        id: user.uid, 
        fullName: formData.name, 
        updatedAt: serverTimestamp() 
      }, { merge: true })

      // Save deep farmer profile with correct mapped keys for persistence
      const profileRef = doc(db, "users", user.uid, "farmerProfile", "main")
      await setDoc(profileRef, { 
        fullName: formData.name,
        language: formData.language,
        state: formData.state,
        district: formData.district,
        totalLandArea: Number(formData.area), 
        areaUnit: formData.areaUnit,
        waterSupplyInfo: formData.water,
        soilType: formData.soil,
        riskTolerance: formData.risk,
        budget: Number(formData.budget), 
        currency: formData.currency,
        marketChannel: formData.marketChannel,
        updatedAt: serverTimestamp() 
      }, { merge: true })

      toast({ title: "Profile Synchronized" })
      router.push("/dashboard")
    } catch (error) {
      toast({ variant: "destructive", title: "Update Failed" })
    } finally {
      setSaving(false)
    }
  }

  if (isUserLoading || isProfileLoading || isUserDataLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="animate-spin text-accent w-10 h-10" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background relative pb-24">
      <Navbar />
      <main className="container mx-auto px-4 pt-32 max-w-5xl">
        <div className="space-y-12">
          <Card className="border-black/5 shadow-2xl bg-white rounded-[3rem] overflow-hidden">
            <CardHeader className="text-center p-10 bg-secondary/10">
              <div className="mx-auto bg-primary/5 p-6 rounded-[2.5rem] w-fit border border-primary/10 mb-6">
                <Briefcase className="w-12 h-12 text-primary" />
              </div>
              <CardTitle className="text-4xl font-headline font-black text-foreground tracking-tighter uppercase">{t('profile_title')}</CardTitle>
              <CardDescription className="text-lg text-foreground/60">Configure your regional and operational parameters.</CardDescription>
            </CardHeader>
            
            <CardContent className="p-10 md:p-16">
              <form onSubmit={handleSubmitProfile} className="space-y-12">
                <div className="space-y-8">
                  <h3 className="text-xl font-black text-foreground tracking-tight uppercase flex items-center gap-2"><UserIcon className="w-5 h-5 text-accent" /> Identity</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-widest font-black text-foreground/40">Full Name</Label>
                      <Input name="name" value={formData.name} onChange={handleInputChange} className="h-14 rounded-xl bg-black/[0.02]" />
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-widest font-black text-foreground/40">Language</Label>
                      <Select value={formData.language} onValueChange={(v) => handleSelectChange("language", v)}>
                        <SelectTrigger className="h-14 rounded-xl bg-black/[0.02]"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="English">English</SelectItem>
                          <SelectItem value="Hindi">Hindi (हिन्दी)</SelectItem>
                          <SelectItem value="Marathi">Marathi (मराठी)</SelectItem>
                          <SelectItem value="Telugu">Telugu (తెలుగు)</SelectItem>
                          <SelectItem value="Tamil">Tamil (தமிழ்)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <div className="space-y-8">
                  <h3 className="text-xl font-black text-foreground tracking-tight uppercase flex items-center gap-2"><MapPin className="w-5 h-5 text-primary" /> Region</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-widest font-black text-foreground/40">State</Label>
                      <Select value={formData.state} onValueChange={(v) => handleSelectChange("state", v)}>
                        <SelectTrigger className="h-14 rounded-xl bg-black/[0.02]"><SelectValue placeholder="Select State" /></SelectTrigger>
                        <SelectContent>{STATES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-widest font-black text-foreground/40">District</Label>
                      <Select value={formData.district} onValueChange={(v) => handleSelectChange("district", v)} disabled={!formData.state}>
                        <SelectTrigger className="h-14 rounded-xl bg-black/[0.02]"><SelectValue placeholder="Select District" /></SelectTrigger>
                        <SelectContent>{(DISTRICT_MAP[formData.state] || []).map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <div className="space-y-8">
                  <h3 className="text-xl font-black text-foreground tracking-tight uppercase flex items-center gap-2"><LandPlot className="w-5 h-5 text-green-600" /> Land & Water</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-widest font-black text-foreground/40">Soil Type</Label>
                      <Select value={formData.soil} onValueChange={(v) => handleSelectChange("soil", v)}>
                        <SelectTrigger className="h-14 rounded-xl bg-black/[0.02]"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Black">Black Soil</SelectItem>
                          <SelectItem value="Clay">Clay Soil</SelectItem>
                          <SelectItem value="Loamy">Loamy Soil</SelectItem>
                          <SelectItem value="Sandy">Sandy Soil</SelectItem>
                          <SelectItem value="Red">Red Soil</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-widest font-black text-foreground/40">Water Supply</Label>
                      <Select value={formData.water} onValueChange={(v) => handleSelectChange("water", v)}>
                        <SelectTrigger className="h-14 rounded-xl bg-black/[0.02]"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Rainfed / Low</SelectItem>
                          <SelectItem value="moderate">Borewell / Moderate</SelectItem>
                          <SelectItem value="high">Drip / Canal / High</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-widest font-black text-foreground/40">Land Area ({formData.areaUnit})</Label>
                      <div className="flex gap-2">
                        <Input type="number" name="area" value={formData.area} onChange={handleInputChange} className="h-14 rounded-xl flex-1 bg-black/[0.02]" />
                        <Select value={formData.areaUnit} onValueChange={(v) => handleSelectChange("areaUnit", v)}>
                          <SelectTrigger className="h-14 w-28 rounded-xl bg-black/[0.02]"><SelectValue /></SelectTrigger>
                          <SelectContent><SelectItem value="acres">Acres</SelectItem><SelectItem value="hectares">Ha</SelectItem></SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-8">
                  <h3 className="text-xl font-black text-foreground tracking-tight uppercase flex items-center gap-2"><Activity className="w-5 h-5 text-amber-500" /> Strategy</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-widest font-black text-foreground/40">Annual Budget ({formData.currency})</Label>
                      <div className="flex gap-2">
                        <Input type="number" name="budget" value={formData.budget} onChange={handleInputChange} className="h-14 rounded-xl flex-1 bg-black/[0.02]" />
                        <Select value={formData.currency} onValueChange={(v) => handleSelectChange("currency", v)}>
                          <SelectTrigger className="h-14 w-24 rounded-xl bg-black/[0.02]"><SelectValue /></SelectTrigger>
                          <SelectContent><SelectItem value="INR">₹ (Rupees)</SelectItem><SelectItem value="USD">$ (USD)</SelectItem></SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-widest font-black text-foreground/40">Risk Tolerance</Label>
                      <Select value={formData.risk} onValueChange={(v) => handleSelectChange("risk", v)}>
                        <SelectTrigger className="h-14 rounded-xl bg-black/[0.02]"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low (Conservative)</SelectItem>
                          <SelectItem value="medium">Medium (Balanced)</SelectItem>
                          <SelectItem value="high">High (Aggressive)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-[10px] uppercase tracking-widest font-black text-foreground/40">Target Market</Label>
                      <Select value={formData.marketChannel} onValueChange={(v) => handleSelectChange("marketChannel", v)}>
                        <SelectTrigger className="h-14 rounded-xl bg-black/[0.02]"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Local">Local Mandi</SelectItem>
                          <SelectItem value="Supermarket">Supermarket Supply</SelectItem>
                          <SelectItem value="Export">Global Export</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <Button type="submit" disabled={saving} className="w-full h-20 text-xl font-black uppercase tracking-tighter rounded-2xl bg-primary text-background shadow-xl hover:scale-[1.02] transition-transform">
                  {saving ? <Loader2 className="animate-spin mr-3" /> : t('profile_save')}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Certificate Management Section */}
          <Card className="border-black/5 shadow-2xl bg-white rounded-[3rem] overflow-hidden">
            <CardHeader className="p-10 pb-4">
              <div className="flex items-center gap-4">
                <div className="bg-accent/10 p-4 rounded-2xl border border-accent/20">
                  <FileBadge className="w-8 h-8 text-accent" />
                </div>
                <div>
                  <CardTitle className="text-3xl font-black text-foreground uppercase tracking-tighter">Certificates & Licenses</CardTitle>
                  <CardDescription>Manage your organic certifications and trading permits.</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-10 space-y-10">
              <form onSubmit={handleAddCertificate} className="grid md:grid-cols-4 gap-6 items-end p-8 rounded-[2rem] bg-black/[0.02] border border-black/5">
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase tracking-widest font-bold">Cert Title</Label>
                  <Input 
                    placeholder="e.g. Organic Cert" 
                    value={newCert.title} 
                    onChange={e => setNewCert(p => ({ ...p, title: e.target.value }))}
                    required
                    className="bg-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase tracking-widest font-bold">Expiry Date</Label>
                  <Input 
                    type="date" 
                    value={newCert.expiryDate} 
                    onChange={e => setNewCert(p => ({ ...p, expiryDate: e.target.value }))}
                    required
                    className="bg-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase tracking-widest font-bold">File (Max 1MB)</Label>
                  <Input 
                    type="file" 
                    accept="image/*,application/pdf" 
                    onChange={handleFileChange}
                    ref={fileInputRef}
                    required
                    className="bg-white cursor-pointer"
                  />
                </div>
                <Button type="submit" disabled={uploadingCert || !newCert.fileDataUri} className="h-10 bg-accent text-background font-black uppercase tracking-widest text-xs rounded-xl">
                  {uploadingCert ? <Loader2 className="animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                  Upload
                </Button>
              </form>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {certificates?.map(cert => {
                  const isExpired = new Date(cert.expiryDate) < new Date();
                  return (
                    <div key={cert.id} className="p-6 rounded-[2rem] bg-black/[0.03] border border-black/5 space-y-4 group">
                      <div className="flex justify-between items-start">
                        <div className="bg-white p-3 rounded-xl shadow-sm"><FileBadge className="w-6 h-6 text-primary" /></div>
                        <Button variant="ghost" size="icon" className="text-foreground/20 hover:text-destructive h-8 w-8 rounded-full" onClick={() => handleDeleteCertificate(cert.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <div>
                        <p className="font-black text-foreground text-lg uppercase line-clamp-1">{cert.title}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Calendar className="w-3 h-3 text-foreground/40" />
                          <p className={`text-[10px] font-bold uppercase ${isExpired ? 'text-destructive' : 'text-foreground/40'}`}>
                            Expires: {cert.expiryDate}
                          </p>
                        </div>
                      </div>
                      <div className="pt-2">
                        {isExpired ? (
                          <Badge variant="destructive" className="w-full justify-center py-1.5 uppercase font-black text-[10px]">Expired</Badge>
                        ) : (
                          <Badge className="w-full justify-center py-1.5 bg-green-500/10 text-green-600 border-green-200 uppercase font-black text-[10px]">Active</Badge>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
