'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { useUser, useFirestore, useDoc, useMemoFirebase } from '@/firebase';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { Language, translations } from '@/lib/translations';

interface LanguageContextType {
  language: Language;
  t: (key: string) => string;
  setLanguage: (lang: Language) => Promise<void>;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const { user } = useUser();
  const db = useFirestore();
  const [currentLanguage, setCurrentLanguage] = useState<Language>('English');

  const profileRef = useMemoFirebase(() => {
    if (!user || !db) return null;
    return doc(db, 'users', user.uid, 'farmerProfile', 'main');
  }, [user, db]);

  const { data: profile } = useDoc(profileRef);

  useEffect(() => {
    if (profile?.language) {
      setCurrentLanguage(profile.language as Language);
    }
  }, [profile]);

  const t = (key: string) => {
    return translations[currentLanguage]?.[key] || translations['English']?.[key] || key;
  };

  const setLanguage = async (lang: Language) => {
    setCurrentLanguage(lang);
    if (user && db) {
      const ref = doc(db, 'users', user.uid, 'farmerProfile', 'main');
      await setDoc(ref, { 
        language: lang,
        updatedAt: serverTimestamp() 
      }, { merge: true });
    }
  };

  return (
    <LanguageContext.Provider value={{ language: currentLanguage, t, setLanguage }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useTranslation() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within a LanguageProvider');
  }
  return context;
}
