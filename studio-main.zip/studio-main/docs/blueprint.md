# **App Name**: AgriVision AI

## Core Features:

- Secure Farmer Authentication: Secure login system with OTP verification and role-based access control.
- Farmer Profile Input: Collect detailed farmer information including land area, water supply, budget, region, and soil type.
- Local Demand & Price Prediction: AI-powered time series forecasting tool for local demand and price range prediction.
- Risk Analysis Model: Classification model tool to assess risk based on weather, flood history, soil condition and price volatility.
- Crop Suitability Model: Multi-factor weighted scoring system tool to determine crop suitability based on environmental conditions.
- Final Crop Recommendation Engine: Combines model outputs to display a ranked list of crop recommendations with detailed information.
- AI Chat Assistant: An AI-powered chat tool allows farmers to ask questions and receive personalized advice regarding crop selection, risk assessment, and export opportunities.

## Style Guidelines:

- Primary color: Dark green (#1B5E20) to evoke agriculture and nature, but with a modern, darker feel.
- Background color: Dark gray (#333333) to provide a sophisticated and contrasting backdrop.
- Accent color: Gold (#FFD700) for highlighting important information and CTAs with a luxurious touch.
- Body and headline font: 'Roboto' for a modern, clean, and readable design on dark backgrounds.
- Visual crop icons with a clean, easily recognizable style, optimized for visibility on dark backgrounds.
- Simple step-by-step flow with large, readable buttons, designed for optimal use on dark themed interfaces.
- Subtle animations and transitions to guide users through the app, ensuring they are clearly visible on a dark interface.